#!/bin/bash
# Stop all SmartComplaint services
LOG_DIR="$(pwd)/logs"
for pid_file in "$LOG_DIR"/*.pid; do
  if [ -f "$pid_file" ]; then
    service=$(basename "$pid_file" .pid)
    pid=$(cat "$pid_file")
    if kill -0 "$pid" 2>/dev/null; then
      kill "$pid"
      echo "🛑 Stopped $service (PID $pid)"
    fi
    rm -f "$pid_file"
  fi
done
echo "All services stopped."
