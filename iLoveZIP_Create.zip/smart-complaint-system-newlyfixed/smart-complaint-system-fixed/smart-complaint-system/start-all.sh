#!/bin/bash
# ============================================================
# SmartComplaint System — Start All Services
# Usage: ./start-all.sh [--mysql]
# Default: H2 in-memory DB (no setup needed)
# MySQL:   ./start-all.sh --mysql  (requires .env file)
# ============================================================

set -e

PROFILE="default"
if [[ "$1" == "--mysql" ]]; then
  PROFILE="mysql"
  echo "🗄  Using MySQL profile"
  if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
    echo "✅ Loaded environment from .env"
  else
    echo "❌ .env file not found. Copy .env.example to .env and fill in your MySQL credentials."
    exit 1
  fi
else
  echo "🧠 Using H2 in-memory database (no setup needed)"
  if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
    echo "✅ Loaded email config from .env"
  else
    echo "⚠️  No .env file. Email notifications will fail (app still works)."
    echo "   Copy .env.example to .env and set MAIL_* variables for real emails."
  fi
fi

ROOT=$(pwd)
LOG_DIR="$ROOT/logs"
mkdir -p "$LOG_DIR"

run_service() {
  local name=$1
  local dir=$2
  echo "🚀 Starting $name..."
  cd "$ROOT/$dir"
  if [[ "$PROFILE" == "mysql" ]]; then
    nohup mvn spring-boot:run -Dspring-boot.run.profiles=mysql > "$LOG_DIR/$name.log" 2>&1 &
  else
    nohup mvn spring-boot:run > "$LOG_DIR/$name.log" 2>&1 &
  fi
  echo $! > "$LOG_DIR/$name.pid"
  echo "   → PID $(cat $LOG_DIR/$name.pid) | Log: logs/$name.log"
  cd "$ROOT"
}

echo ""
echo "═══════════════════════════════════════════════"
echo "  SmartComplaint System — Starting Services"
echo "═══════════════════════════════════════════════"
echo ""

# 1. Eureka (service registry)
run_service "eureka-server" "eureka-server"
echo "   Waiting 20s for Eureka to come up..."
sleep 20

# 2. Auth Service
run_service "auth-service" "auth-service"

# 3. Notification Service
run_service "notification-service" "notification-service"

# 4. Ticket Service
run_service "ticket-service" "ticket-service"

# 5. Agent Service
run_service "agent-service" "agent-service"

# 6. API Gateway (last — routes to all others)
echo "   Waiting 15s for services to register with Eureka..."
sleep 15
run_service "api-gateway" "api-gateway"

echo ""
echo "═══════════════════════════════════════════════"
echo "  All services starting! Wait ~30s then open:"
echo ""
echo "  🌐 Frontend    →  frontend/index.html (open in browser)"
echo "  🔀 API Gateway →  http://localhost:8080"
echo "  🔑 Auth API    →  http://localhost:8081/swagger-ui.html"
echo "  🎫 Ticket API  →  http://localhost:8082/swagger-ui.html"
echo "  🔔 Notif API   →  http://localhost:8083/swagger-ui.html"
echo "  🤝 Agent API   →  http://localhost:8084/swagger-ui.html"
echo "  🌍 Eureka UI   →  http://localhost:8761"
echo ""
echo "  📊 H2 Consoles (dev mode only):"
echo "     Auth:    http://localhost:8081/h2-console   (JDBC: jdbc:h2:mem:authdb)"
echo "     Ticket:  http://localhost:8082/h2-console   (JDBC: jdbc:h2:mem:ticketdb)"
echo "     Notif:   http://localhost:8083/h2-console   (JDBC: jdbc:h2:mem:notificationdb)"
echo "     Agent:   http://localhost:8084/h2-console   (JDBC: jdbc:h2:mem:agentdb)"
echo ""
echo "  Logs: $LOG_DIR/"
echo "═══════════════════════════════════════════════"
