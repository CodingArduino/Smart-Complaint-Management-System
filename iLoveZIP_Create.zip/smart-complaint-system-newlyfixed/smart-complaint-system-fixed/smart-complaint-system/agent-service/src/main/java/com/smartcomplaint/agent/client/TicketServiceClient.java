package com.smartcomplaint.agent.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

/**
 * WebClient-based inter-service client for Ticket Service.
 * Agent Service calls Ticket Service to assign tickets — demonstrating
 * synchronous inter-microservice communication via Eureka load-balanced WebClient.
 */
@Component
public class TicketServiceClient {

    private static final Logger logger = LoggerFactory.getLogger(TicketServiceClient.class);

    private final WebClient webClient;

    public TicketServiceClient(WebClient.Builder webClientBuilder,
                                @Value("${services.ticket.url}") String ticketServiceUrl) {
        this.webClient = webClientBuilder.baseUrl(ticketServiceUrl).build();
    }

    /**
     * Calls ticket-service to assign a ticket to an agent.
     * Uses the internal PATCH /tickets/{id}/assign/{agentEmail} endpoint.
     *
     * @param ticketId   ticket to assign
     * @param agentEmail email of the agent being assigned
     */
    public void assignTicket(Long ticketId, String agentEmail) {
        logger.info("Calling ticket-service to assign ticket {} to agent {}", ticketId, agentEmail);
        webClient.patch()
                .uri("/tickets/{id}/assign/{agentEmail}", ticketId, agentEmail)
                .retrieve()
                .bodyToMono(Map.class)
                .doOnSuccess(r -> logger.info("Ticket {} assigned via ticket-service", ticketId))
                .doOnError(e -> logger.error("Failed to assign ticket {} in ticket-service: {}", ticketId, e.getMessage()))
                .onErrorResume(e -> Mono.empty())
                .subscribe();
    }
}
