package com.smartcomplaint.agent.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.*;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;

/** Configuration beans for Agent Service: WebClient (load-balanced) and OpenAPI. */
@Configuration
public class AppConfig {

    /** Load-balanced WebClient resolves Eureka service names to real instances. */
    @Bean
    @LoadBalanced
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }

    @Bean
    public OpenAPI agentServiceOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("Agent Service API")
                .description("Support agent management and ticket assignment. Calls ticket-service internally.")
                .version("1.0.0"))
            .addSecurityItem(new SecurityRequirement().addList("BearerAuth"))
            .components(new Components().addSecuritySchemes("BearerAuth",
                new SecurityScheme()
                    .type(SecurityScheme.Type.HTTP)
                    .scheme("bearer")
                    .bearerFormat("JWT")));
    }
}
