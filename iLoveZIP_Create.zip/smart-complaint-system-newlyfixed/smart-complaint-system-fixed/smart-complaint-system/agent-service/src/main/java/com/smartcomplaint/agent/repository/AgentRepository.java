package com.smartcomplaint.agent.repository;

import com.smartcomplaint.agent.entity.Agent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface AgentRepository extends JpaRepository<Agent, Long> {
    Optional<Agent> findByEmail(String email);
    boolean existsByEmail(String email);
    List<Agent> findByStatus(Agent.AgentStatus status);
    List<Agent> findBySpecializationAndStatus(Agent.Specialization spec, Agent.AgentStatus status);
    /** Find the least-loaded available agent for a given specialization */
    Optional<Agent> findFirstBySpecializationAndStatusOrderByActiveTicketCountAsc(
            Agent.Specialization spec, Agent.AgentStatus status);
}
