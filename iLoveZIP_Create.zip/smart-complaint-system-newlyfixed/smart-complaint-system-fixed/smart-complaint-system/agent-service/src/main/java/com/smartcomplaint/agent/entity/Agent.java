package com.smartcomplaint.agent.entity;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
/**
 * Agent entity — represents a support agent registered in the agent-service.
 * Stored in agent-service's own isolated H2 database.
 * Cross-service reference to tickets uses ticketId (Long), not a JPA relationship.
 */
@Entity
@Table(name = "agents", indexes = {
    @Index(name = "idx_agent_email", columnList = "email", unique = true)
})
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Agent {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 100)
    private String name;
    @Column(unique = true, nullable = false, length = 100)
    private String email;
    /** Specialization for routing tickets to the right agent */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private Specialization specialization;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private AgentStatus status;
    /** Number of tickets currently assigned to this agent */
    @Column(nullable = false)
    private int activeTicketCount;
    @Column(length = 500)
    private String statusNote;
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;
    @Column
    private LocalDateTime updatedAt;
    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
        if (this.status == null) this.status = AgentStatus.AVAILABLE;
        this.activeTicketCount = 0;
    }
    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
    public enum Specialization { BILLING, TECHNICAL, GENERAL, COMPLAINT }
    public enum AgentStatus { AVAILABLE, BUSY, OFFLINE }
}