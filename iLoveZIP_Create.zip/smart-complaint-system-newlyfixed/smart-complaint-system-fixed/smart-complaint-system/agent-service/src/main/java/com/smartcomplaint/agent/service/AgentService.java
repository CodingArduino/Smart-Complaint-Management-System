package com.smartcomplaint.agent.service;

import com.smartcomplaint.agent.client.TicketServiceClient;
import com.smartcomplaint.agent.dto.AgentDTOs;
import com.smartcomplaint.agent.entity.Agent;
import com.smartcomplaint.agent.exception.AgentNotFoundException;
import com.smartcomplaint.agent.exception.DuplicateAgentEmailException;
import com.smartcomplaint.agent.repository.AgentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Agent Service business logic.
 *
 * Responsibilities:
 * - Agent registration and management
 * - Intelligent ticket assignment (least-loaded available agent)
 * - Inter-service call to ticket-service via TicketServiceClient
 */
@Service
public class AgentService {

    private static final Logger logger = LoggerFactory.getLogger(AgentService.class);

    private final AgentRepository agentRepository;
    private final TicketServiceClient ticketServiceClient;

    public AgentService(AgentRepository agentRepository,
                        TicketServiceClient ticketServiceClient) {
        this.agentRepository    = agentRepository;
        this.ticketServiceClient = ticketServiceClient;
    }

    /**
     * Registers a new support agent.
     *
     * @param request agent details
     * @return AgentResponse DTO
     * @throws DuplicateAgentEmailException if email already registered
     */
    @Transactional
    public AgentDTOs.AgentResponse registerAgent(AgentDTOs.CreateAgentRequest request) {
        logger.info("Registering agent: {} ({})", request.getName(), request.getEmail());

        if (agentRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateAgentEmailException("Agent email already registered: " + request.getEmail());
        }

        Agent agent = Agent.builder()
                .name(request.getName())
                .email(request.getEmail())
                .specialization(request.getSpecialization())
                .build();

        Agent saved = agentRepository.save(agent);
        logger.info("Agent registered with ID: {}", saved.getId());
        return AgentDTOs.AgentResponse.from(saved);
    }

    /** Returns all registered agents. */
    @Transactional(readOnly = true)
    public List<AgentDTOs.AgentResponse> getAllAgents() {
        return agentRepository.findAll().stream()
                .map(AgentDTOs.AgentResponse::from).collect(Collectors.toList());
    }

    /** Returns a single agent by ID. */
    @Transactional(readOnly = true)
    public AgentDTOs.AgentResponse getAgentById(Long id) {
        Agent agent = agentRepository.findById(id)
                .orElseThrow(() -> new AgentNotFoundException("Agent not found with ID: " + id));
        return AgentDTOs.AgentResponse.from(agent);
    }

    /** Returns all currently available agents. */
    @Transactional(readOnly = true)
    public List<AgentDTOs.AgentResponse> getAvailableAgents() {
        return agentRepository.findByStatus(Agent.AgentStatus.AVAILABLE).stream()
                .map(AgentDTOs.AgentResponse::from).collect(Collectors.toList());
    }

    /**
     * Assigns a ticket to a specific agent and calls ticket-service to reflect the assignment.
     * Increments the agent's active ticket count and updates status to BUSY if threshold met.
     *
     * @param request assignment request (agentId + ticketId)
     * @return updated AgentResponse
     */
    @Transactional
    public AgentDTOs.AgentResponse assignTicket(AgentDTOs.AssignTicketRequest request) {
        logger.info("Assigning ticket {} to agent {}", request.getTicketId(), request.getAgentId());

        Agent agent = agentRepository.findById(request.getAgentId())
                .orElseThrow(() -> new AgentNotFoundException("Agent not found: " + request.getAgentId()));

        agent.setActiveTicketCount(agent.getActiveTicketCount() + 1);

        // Mark agent BUSY if handling 5+ active tickets
        if (agent.getActiveTicketCount() >= 5) {
            agent.setStatus(Agent.AgentStatus.BUSY);
        }

        Agent updated = agentRepository.save(agent);

        // Inter-service call → ticket-service updates the ticket's assignedAgentEmail
        ticketServiceClient.assignTicket(request.getTicketId(), agent.getEmail());

        logger.info("Ticket {} assigned to agent {} (total active: {})",
                request.getTicketId(), agent.getEmail(), updated.getActiveTicketCount());
        return AgentDTOs.AgentResponse.from(updated);
    }

    /**
     * Auto-assigns a ticket to the least-loaded available agent matching the given specialization.
     * Falls back to any available agent if no specialist is available.
     *
     * @param ticketId       ticket to auto-assign
     * @param specialization preferred agent specialization
     * @return AgentResponse of the assigned agent
     */
    @Transactional
    public AgentDTOs.AgentResponse autoAssignTicket(Long ticketId, String specialization) {
        logger.info("Auto-assigning ticket {} for specialization: {}", ticketId, specialization);

        Agent.Specialization spec;
        try {
            spec = Agent.Specialization.valueOf(specialization.toUpperCase());
        } catch (IllegalArgumentException e) {
            spec = Agent.Specialization.GENERAL;
        }

        // Find the least-loaded available specialist
        Agent agent = agentRepository
                .findFirstBySpecializationAndStatusOrderByActiveTicketCountAsc(spec, Agent.AgentStatus.AVAILABLE)
                .orElseGet(() ->
                    // Fallback: any available agent
                    agentRepository.findByStatus(Agent.AgentStatus.AVAILABLE).stream()
                            .findFirst()
                            .orElseThrow(() -> new RuntimeException("No available agents at this time"))
                );

        AgentDTOs.AssignTicketRequest req = new AgentDTOs.AssignTicketRequest(agent.getId(), ticketId);
        return assignTicket(req);
    }

    /**
     * Updates agent status (AVAILABLE / BUSY / OFFLINE), optionally with a note.
     */
    @Transactional
    public AgentDTOs.AgentResponse updateStatus(Long agentId, Agent.AgentStatus status, String note) {
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new AgentNotFoundException("Agent not found: " + agentId));
        agent.setStatus(status);
        if (note != null) {
            agent.setStatusNote(note.isBlank() ? null : note.trim());
        }
        if (status == Agent.AgentStatus.AVAILABLE) {
            agent.setActiveTicketCount(0); // Reset on becoming available again
        }
        return AgentDTOs.AgentResponse.from(agentRepository.save(agent));
    }
}