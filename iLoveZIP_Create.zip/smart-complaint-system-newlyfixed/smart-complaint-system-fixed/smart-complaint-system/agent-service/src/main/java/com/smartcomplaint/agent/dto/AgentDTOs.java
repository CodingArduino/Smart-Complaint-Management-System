package com.smartcomplaint.agent.dto;
import com.smartcomplaint.agent.entity.Agent;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import java.time.LocalDateTime;
/** DTOs for Agent Service — clean API contract decoupled from entity. */
public class AgentDTOs {
    @Data @NoArgsConstructor @AllArgsConstructor
    @Schema(description = "Payload to register a new agent")
    public static class CreateAgentRequest {
        @NotBlank(message = "Name is required")
        @Schema(example = "Alice Smith")
        private String name;
        @NotBlank(message = "Email is required")
        @Email(message = "Valid email required")
        @Schema(example = "alice@support.com")
        private String email;
        @NotNull(message = "Specialization is required")
        @Schema(example = "TECHNICAL")
        private Agent.Specialization specialization;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    @Schema(description = "Request to assign a ticket to an agent")
    public static class AssignTicketRequest {
        @NotNull(message = "Agent ID is required")
        @Schema(example = "1")
        private Long agentId;
        @NotNull(message = "Ticket ID is required")
        @Schema(example = "5")
        private Long ticketId;
    }
    @Data @NoArgsConstructor @AllArgsConstructor
    @Schema(description = "Payload to update an agent's status, with an optional note")
    public static class UpdateStatusRequest {
        @Schema(example = "Back in 20 minutes")
        private String note;
    }
    @Data @NoArgsConstructor
    @Schema(description = "Agent details returned by the API")
    public static class AgentResponse {
        private Long id;
        private String name;
        private String email;
        private String specialization;
        private String status;
        private String statusNote;
        private int activeTicketCount;
        private LocalDateTime createdAt;
        public static AgentResponse from(Agent a) {
            AgentResponse r = new AgentResponse();
            r.setId(a.getId()); r.setName(a.getName()); r.setEmail(a.getEmail());
            r.setSpecialization(a.getSpecialization().name());
            r.setStatus(a.getStatus().name());
            r.setStatusNote(a.getStatusNote());
            r.setActiveTicketCount(a.getActiveTicketCount());
            r.setCreatedAt(a.getCreatedAt());
            return r;
        }
    }
    @Data @AllArgsConstructor @NoArgsConstructor
    public static class ApiResponse {
        private String message;
        private boolean success;
    }
}
