package com.smartcomplaint.agent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Agent Service — manages support agents and ticket assignments.
 * Communicates with Ticket Service (WebClient) for cross-service ticket assignment updates.
 * Has its own isolated H2 database — no shared state with other services.
 */
@SpringBootApplication
public class AgentServiceApplication {

    private static final Logger logger = LoggerFactory.getLogger(AgentServiceApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(AgentServiceApplication.class, args);
        logger.info("Agent Service started successfully on port 8084");
    }
}
