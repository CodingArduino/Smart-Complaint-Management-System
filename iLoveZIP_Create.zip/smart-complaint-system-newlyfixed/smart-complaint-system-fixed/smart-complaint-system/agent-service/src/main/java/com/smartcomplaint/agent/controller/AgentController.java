package com.smartcomplaint.agent.controller;

import com.smartcomplaint.agent.dto.AgentDTOs;
import com.smartcomplaint.agent.entity.Agent;
import com.smartcomplaint.agent.service.AgentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Agent REST Controller.
 * Accessible via API Gateway at: /api/agents/**
 * All endpoints require JWT (enforced at Gateway).
 * Calls ticket-service via WebClient for ticket assignments (inter-service communication).
 */
@RestController
@RequestMapping("/agents")
@CrossOrigin(origins = "*")
@Tag(name = "Agents", description = "Support agent management and ticket assignment")
@SecurityRequirement(name = "BearerAuth")
public class AgentController {

    private static final Logger logger = LoggerFactory.getLogger(AgentController.class);
    private final AgentService agentService;

    public AgentController(AgentService agentService) {
        this.agentService = agentService;
    }

    @Operation(summary = "Register a new support agent")
    @PostMapping
    public ResponseEntity<AgentDTOs.AgentResponse> registerAgent(
            @Valid @RequestBody AgentDTOs.CreateAgentRequest request) {
        logger.info("POST /agents | registering: {}", request.getEmail());
        return ResponseEntity.status(HttpStatus.CREATED).body(agentService.registerAgent(request));
    }

    @Operation(summary = "Get all agents")
    @GetMapping
    public ResponseEntity<List<AgentDTOs.AgentResponse>> getAllAgents() {
        logger.info("GET /agents");
        return ResponseEntity.ok(agentService.getAllAgents());
    }

    @Operation(summary = "Get agent by ID")
    @GetMapping("/{id}")
    public ResponseEntity<AgentDTOs.AgentResponse> getAgentById(@PathVariable Long id) {
        logger.info("GET /agents/{}", id);
        return ResponseEntity.ok(agentService.getAgentById(id));
    }

    @Operation(summary = "Get available agents")
    @GetMapping("/available")
    public ResponseEntity<List<AgentDTOs.AgentResponse>> getAvailableAgents() {
        logger.info("GET /agents/available");
        return ResponseEntity.ok(agentService.getAvailableAgents());
    }

    @Operation(summary = "Manually assign a ticket to an agent",
               description = "Calls ticket-service internally to update the ticket record.")
    @PostMapping("/assign")
    public ResponseEntity<AgentDTOs.AgentResponse> assignTicket(
            @Valid @RequestBody AgentDTOs.AssignTicketRequest request) {
        logger.info("POST /agents/assign | ticket: {} → agent: {}", request.getTicketId(), request.getAgentId());
        return ResponseEntity.ok(agentService.assignTicket(request));
    }

    @Operation(summary = "Auto-assign ticket to least-loaded available agent",
               description = "Finds the best agent by specialization match and current load.")
    @PostMapping("/auto-assign/{ticketId}/{specialization}")
    public ResponseEntity<AgentDTOs.AgentResponse> autoAssign(
            @PathVariable Long ticketId,
            @PathVariable String specialization) {
        logger.info("POST /agents/auto-assign/{}/{}", ticketId, specialization);
        return ResponseEntity.ok(agentService.autoAssignTicket(ticketId, specialization));
    }

    @Operation(summary = "Update agent status (AVAILABLE/BUSY/OFFLINE), optionally with a note")
    @PatchMapping("/{id}/status/{status}")
    public ResponseEntity<AgentDTOs.AgentResponse> updateStatus(
            @PathVariable Long id,
            @PathVariable Agent.AgentStatus status,
            @RequestBody(required = false) AgentDTOs.UpdateStatusRequest request) {
        String note = request != null ? request.getNote() : null;
        logger.info("PATCH /agents/{}/status/{} | note: {}", id, status, note);
        return ResponseEntity.ok(agentService.updateStatus(id, status, note));
    }

    @GetMapping("/health")
    public ResponseEntity<AgentDTOs.ApiResponse> health() {
        return ResponseEntity.ok(new AgentDTOs.ApiResponse("Agent Service is running", true));
    }
}
