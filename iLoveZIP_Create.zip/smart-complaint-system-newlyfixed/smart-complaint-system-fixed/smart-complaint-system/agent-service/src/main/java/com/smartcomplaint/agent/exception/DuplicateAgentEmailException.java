package com.smartcomplaint.agent.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class DuplicateAgentEmailException extends RuntimeException {
    public DuplicateAgentEmailException(String message) { super(message); }
}
