package com.smartcomplaint.agent.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(AgentNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(AgentNotFoundException ex) {
        logger.warn("Agent not found: {}", ex.getMessage());
        return build(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(DuplicateAgentEmailException.class)
    public ResponseEntity<Map<String, Object>> handleDuplicate(DuplicateAgentEmailException ex) {
        logger.warn("Duplicate agent email: {}", ex.getMessage());
        return build(ex.getMessage(), HttpStatus.CONFLICT);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException ex) {
        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(e ->
            fieldErrors.put(((FieldError) e).getField(), e.getDefaultMessage()));
        logger.warn("Validation failed: {}", fieldErrors);
        Map<String, Object> body = new HashMap<>();
        body.put("error", "Validation failed"); body.put("fieldErrors", fieldErrors);
        body.put("status", 400); body.put("timestamp", LocalDateTime.now().toString());
        return ResponseEntity.badRequest().body(body);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGeneric(Exception ex) {
        logger.error("Unexpected error: {}", ex.getMessage(), ex);
        return build("An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private ResponseEntity<Map<String, Object>> build(String msg, HttpStatus status) {
        return ResponseEntity.status(status).body(Map.of(
            "error", msg, "status", status.value(), "timestamp", LocalDateTime.now().toString()));
    }
}
