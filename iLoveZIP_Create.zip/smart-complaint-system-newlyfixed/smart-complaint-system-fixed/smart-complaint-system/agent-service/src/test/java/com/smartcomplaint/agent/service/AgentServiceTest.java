package com.smartcomplaint.agent.service;

import com.smartcomplaint.agent.client.TicketServiceClient;
import com.smartcomplaint.agent.dto.AgentDTOs;
import com.smartcomplaint.agent.entity.Agent;
import com.smartcomplaint.agent.exception.AgentNotFoundException;
import com.smartcomplaint.agent.exception.DuplicateAgentEmailException;
import com.smartcomplaint.agent.repository.AgentRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AgentServiceTest {

    @Mock AgentRepository agentRepository;
    @Mock TicketServiceClient ticketServiceClient;
    @InjectMocks AgentService agentService;

    private Agent sampleAgent;

    @BeforeEach
    void setUp() {
        sampleAgent = Agent.builder()
                .id(1L).name("Alice").email("alice@support.com")
                .specialization(Agent.Specialization.TECHNICAL)
                .status(Agent.AgentStatus.AVAILABLE).activeTicketCount(0).build();
    }

    @Test @DisplayName("registerAgent() - success")
    void registerAgent_success() {
        AgentDTOs.CreateAgentRequest req = new AgentDTOs.CreateAgentRequest(
                "Alice", "alice@support.com", Agent.Specialization.TECHNICAL);

        when(agentRepository.existsByEmail("alice@support.com")).thenReturn(false);
        when(agentRepository.save(any())).thenReturn(sampleAgent);

        AgentDTOs.AgentResponse response = agentService.registerAgent(req);

        assertThat(response.getName()).isEqualTo("Alice");
        assertThat(response.getSpecialization()).isEqualTo("TECHNICAL");
        verify(agentRepository).save(any(Agent.class));
    }

    @Test @DisplayName("registerAgent() - duplicate email throws exception")
    void registerAgent_duplicateEmail() {
        AgentDTOs.CreateAgentRequest req = new AgentDTOs.CreateAgentRequest(
                "Alice", "alice@support.com", Agent.Specialization.TECHNICAL);
        when(agentRepository.existsByEmail("alice@support.com")).thenReturn(true);

        assertThatThrownBy(() -> agentService.registerAgent(req))
                .isInstanceOf(DuplicateAgentEmailException.class);
        verify(agentRepository, never()).save(any());
    }

    @Test @DisplayName("assignTicket() - increments activeTicketCount and calls ticket-service")
    void assignTicket_success() {
        AgentDTOs.AssignTicketRequest req = new AgentDTOs.AssignTicketRequest(1L, 10L);

        when(agentRepository.findById(1L)).thenReturn(Optional.of(sampleAgent));
        when(agentRepository.save(any())).thenReturn(sampleAgent);
        doNothing().when(ticketServiceClient).assignTicket(10L, "alice@support.com");

        AgentDTOs.AgentResponse response = agentService.assignTicket(req);

        verify(ticketServiceClient).assignTicket(10L, "alice@support.com");
        assertThat(response).isNotNull();
    }

    @Test @DisplayName("getAgentById() - not found throws AgentNotFoundException")
    void getAgentById_notFound() {
        when(agentRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> agentService.getAgentById(99L))
                .isInstanceOf(AgentNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test @DisplayName("getAvailableAgents() - returns only AVAILABLE agents")
    void getAvailableAgents() {
        when(agentRepository.findByStatus(Agent.AgentStatus.AVAILABLE))
                .thenReturn(List.of(sampleAgent));

        List<AgentDTOs.AgentResponse> result = agentService.getAvailableAgents();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStatus()).isEqualTo("AVAILABLE");
    }
}
