-- ============================================================
-- SmartComplaint System — MySQL Database Setup
-- Run this before starting services with --mysql profile
-- ============================================================

CREATE DATABASE IF NOT EXISTS authdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS ticketdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS notificationdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE DATABASE IF NOT EXISTS agentdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Optional: create a dedicated user
-- CREATE USER 'smartcomplaint'@'localhost' IDENTIFIED BY 'yourpassword';
-- GRANT ALL PRIVILEGES ON authdb.* TO 'smartcomplaint'@'localhost';
-- GRANT ALL PRIVILEGES ON ticketdb.* TO 'smartcomplaint'@'localhost';
-- GRANT ALL PRIVILEGES ON notificationdb.* TO 'smartcomplaint'@'localhost';
-- GRANT ALL PRIVILEGES ON agentdb.* TO 'smartcomplaint'@'localhost';
-- FLUSH PRIVILEGES;

SHOW DATABASES LIKE '%db';
