package com.smartcomplaint.auth.service;

import com.smartcomplaint.auth.dto.AuthDTOs;
import com.smartcomplaint.auth.entity.User;
import com.smartcomplaint.auth.exception.DuplicateEmailException;
import com.smartcomplaint.auth.exception.InvalidCredentialsException;
import com.smartcomplaint.auth.repository.UserRepository;
import com.smartcomplaint.auth.security.JwtUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for AuthService using JUnit 5 + Mockito.
 * All dependencies are mocked — no Spring context, no DB required.
 */
@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtils jwtUtils;

    @InjectMocks
    private AuthService authService;

    private AuthDTOs.RegisterRequest registerRequest;
    private AuthDTOs.LoginRequest loginRequest;
    private User storedUser;

    @BeforeEach
    void setUp() {
        registerRequest = new AuthDTOs.RegisterRequest("John Doe", "john@example.com", "Pass1234", null);
        loginRequest = new AuthDTOs.LoginRequest("john@example.com", "Pass1234");
        storedUser = User.builder()
                .id(1L)
                .name("John Doe")
                .email("john@example.com")
                .password("$2a$12$encodedPassword")
                .role(User.Role.USER)
                .build();
    }

    // ─── register() tests ───────────────────────────────────────────────────

    @Test
    @DisplayName("register() - success: returns AuthResponse with token")
    void register_success() {
        when(userRepository.existsByEmail("john@example.com")).thenReturn(false);
        when(passwordEncoder.encode("Pass1234")).thenReturn("$2a$12$encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(storedUser);
        when(jwtUtils.generateToken("john@example.com", "USER")).thenReturn("mock.jwt.token");

        AuthDTOs.AuthResponse response = authService.register(registerRequest);

        assertThat(response.getToken()).isEqualTo("mock.jwt.token");
        assertThat(response.getEmail()).isEqualTo("john@example.com");
        assertThat(response.getRole()).isEqualTo("USER");

        verify(userRepository, times(1)).save(any(User.class));
        verify(passwordEncoder, times(1)).encode("Pass1234");
    }

    @Test
    @DisplayName("register() - duplicate email: throws DuplicateEmailException")
    void register_duplicateEmail_throwsException() {
        when(userRepository.existsByEmail("john@example.com")).thenReturn(true);

        assertThatThrownBy(() -> authService.register(registerRequest))
                .isInstanceOf(DuplicateEmailException.class)
                .hasMessageContaining("already registered");

        verify(userRepository, never()).save(any());
    }

    @Test
    @DisplayName("register() - with explicit AGENT role: persists AGENT role")
    void register_withExplicitRole_persistsRole() {
        registerRequest.setRole(User.Role.AGENT);
        User agentUser = User.builder().email("john@example.com").role(User.Role.AGENT).name("John Doe").build();

        when(userRepository.existsByEmail(anyString())).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("encoded");
        when(userRepository.save(any())).thenReturn(agentUser);
        when(jwtUtils.generateToken(anyString(), eq("AGENT"))).thenReturn("agent.token");

        AuthDTOs.AuthResponse response = authService.register(registerRequest);
        assertThat(response.getRole()).isEqualTo("AGENT");
    }

    // ─── login() tests ───────────────────────────────────────────────────────

    @Test
    @DisplayName("login() - success: returns AuthResponse with token")
    void login_success() {
        when(userRepository.findByEmail("john@example.com")).thenReturn(Optional.of(storedUser));
        when(passwordEncoder.matches("Pass1234", "$2a$12$encodedPassword")).thenReturn(true);
        when(jwtUtils.generateToken("john@example.com", "USER")).thenReturn("mock.jwt.token");

        AuthDTOs.AuthResponse response = authService.login(loginRequest);

        assertThat(response.getToken()).isEqualTo("mock.jwt.token");
        assertThat(response.getEmail()).isEqualTo("john@example.com");
    }

    @Test
    @DisplayName("login() - user not found: throws InvalidCredentialsException")
    void login_userNotFound_throwsException() {
        when(userRepository.findByEmail("john@example.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.login(loginRequest))
                .isInstanceOf(InvalidCredentialsException.class)
                .hasMessageContaining("Invalid email or password");
    }

    @Test
    @DisplayName("login() - wrong password: throws InvalidCredentialsException")
    void login_wrongPassword_throwsException() {
        when(userRepository.findByEmail("john@example.com")).thenReturn(Optional.of(storedUser));
        when(passwordEncoder.matches("Pass1234", "$2a$12$encodedPassword")).thenReturn(false);

        assertThatThrownBy(() -> authService.login(loginRequest))
                .isInstanceOf(InvalidCredentialsException.class)
                .hasMessageContaining("Invalid email or password");

        verify(jwtUtils, never()).generateToken(anyString(), anyString());
    }
}
