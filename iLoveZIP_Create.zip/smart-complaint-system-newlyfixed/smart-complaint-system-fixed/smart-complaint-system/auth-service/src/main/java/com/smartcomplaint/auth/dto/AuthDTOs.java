package com.smartcomplaint.auth.dto;

import com.smartcomplaint.auth.entity.User;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Data Transfer Objects for Auth Service.
 * Validation annotations enforce data integrity at the controller layer.
 */
public class AuthDTOs {

    // ─────────────────────────────────────────────────
    // Request DTOs
    // ─────────────────────────────────────────────────

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Registration request payload")
    public static class RegisterRequest {

        @NotBlank(message = "Name is required")
        @Size(min = 2, max = 100, message = "Name must be between 2 and 100 characters")
        @Schema(description = "Full name of the user", example = "John Doe")
        private String name;

        @NotBlank(message = "Email is required")
        @Email(message = "Email must be a valid address")
        @Schema(description = "Unique email address", example = "john@example.com")
        private String email;

        @NotBlank(message = "Password is required")
        @Size(min = 8, max = 64, message = "Password must be between 8 and 64 characters")
        @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$",
                 message = "Password must contain at least one letter and one number")
        @Schema(description = "Password (min 8 chars, must have letter + digit)", example = "Pass1234")
        private String password;

        /** Optional — defaults to USER if not specified */
        @Schema(description = "Role to assign (defaults to USER)", example = "USER")
        private User.Role role;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Login request payload")
    public static class LoginRequest {

        @NotBlank(message = "Email is required")
        @Email(message = "Email must be a valid address")
        @Schema(description = "Registered email", example = "john@example.com")
        private String email;

        @NotBlank(message = "Password is required")
        @Schema(description = "User password", example = "Pass1234")
        private String password;
    }

    // ─────────────────────────────────────────────────
    // Response DTOs
    // ─────────────────────────────────────────────────

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Authentication response with JWT token")
    public static class AuthResponse {
        @Schema(description = "JWT Bearer token")
        private String token;

        @Schema(description = "User email")
        private String email;

        @Schema(description = "User display name")
        private String name;

        @Schema(description = "Assigned role", example = "USER")
        private String role;

        @Schema(description = "Token type", example = "Bearer")
        private String tokenType = "Bearer";

        public AuthResponse(String token, String email, String name, String role) {
            this.token = token;
            this.email = email;
            this.name = name;
            this.role = role;
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Generic API response")
    public static class ApiResponse {
        @Schema(description = "Response message")
        private String message;

        @Schema(description = "Operation success flag")
        private boolean success;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Schema(description = "Validation error response")
    public static class ErrorResponse {
        @Schema(description = "Error field name")
        private String field;

        @Schema(description = "Error description")
        private String message;

        private long timestamp = System.currentTimeMillis();

        public ErrorResponse(String field, String message) {
            this.field = field;
            this.message = message;
        }
    }
}
