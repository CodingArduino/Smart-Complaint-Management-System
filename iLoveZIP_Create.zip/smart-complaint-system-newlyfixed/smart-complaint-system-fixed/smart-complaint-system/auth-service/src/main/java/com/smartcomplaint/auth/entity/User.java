package com.smartcomplaint.auth.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * User entity — stores credentials and role information.
 * Password is BCrypt-encoded before persistence.
 */
@Entity
@Table(name = "users", indexes = {
        @Index(name = "idx_user_email", columnList = "email", unique = true)
})
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Unique login identifier */
    @Column(unique = true, nullable = false, length = 100)
    private String email;

    /** BCrypt-hashed password — never stored in plain text */
    @Column(nullable = false)
    private String password;

    @Column(nullable = false, length = 100)
    private String name;

    /** Role controls access: USER submits tickets, AGENT handles them, ADMIN has full access */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime updatedAt;

    /** Automatically sets creation timestamp and defaults role to USER */
    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
        if (this.role == null) {
            this.role = Role.USER;
        }
    }

    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }

    public enum Role {
        USER,   // Can submit and view own tickets
        AGENT,  // Can view and update all tickets
        ADMIN   // Full system access
    }
}
