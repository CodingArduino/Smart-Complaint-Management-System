package com.smartcomplaint.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Auth Service - Handles user registration, login, and JWT issuance.
 * Roles: USER, AGENT, ADMIN — BCrypt password encoding — Stateless JWT auth.
 */
@SpringBootApplication
public class AuthServiceApplication {

    private static final Logger logger = LoggerFactory.getLogger(AuthServiceApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(AuthServiceApplication.class, args);
        logger.info("Auth Service started successfully on port 8081");
    }
}
