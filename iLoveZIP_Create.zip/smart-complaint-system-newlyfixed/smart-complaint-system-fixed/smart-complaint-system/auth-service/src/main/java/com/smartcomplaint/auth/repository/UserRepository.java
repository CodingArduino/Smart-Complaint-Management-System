package com.smartcomplaint.auth.repository;

import com.smartcomplaint.auth.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * JPA Repository for User entity.
 * Spring Data generates SQL queries from method name conventions.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    /**
     * Find a user by their unique email address.
     * Used for login and duplicate-registration checks.
     */
    Optional<User> findByEmail(String email);

    /**
     * Check whether an email is already registered.
     * More efficient than findByEmail for existence checks.
     */
    boolean existsByEmail(String email);
}
