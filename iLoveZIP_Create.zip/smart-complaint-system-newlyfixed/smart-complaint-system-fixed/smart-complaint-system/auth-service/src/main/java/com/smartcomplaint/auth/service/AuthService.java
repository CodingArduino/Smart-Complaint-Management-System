package com.smartcomplaint.auth.service;

import com.smartcomplaint.auth.dto.AuthDTOs;
import com.smartcomplaint.auth.entity.User;
import com.smartcomplaint.auth.exception.DuplicateEmailException;
import com.smartcomplaint.auth.exception.InvalidCredentialsException;
import com.smartcomplaint.auth.repository.UserRepository;
import com.smartcomplaint.auth.security.JwtUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Business logic for user authentication.
 *
 * Design:
 * - Uses constructor injection (SOLID: DI, no field injection)
 * - Throws typed exceptions (not raw RuntimeException) for clean error handling
 * - All DB writes are @Transactional
 * - Passwords are BCrypt-encoded before persistence
 */
@Service
public class AuthService {

    private static final Logger logger = LoggerFactory.getLogger(AuthService.class);

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;

    public AuthService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       JwtUtils jwtUtils) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
    }

    /**
     * Registers a new user and returns a signed JWT.
     *
     * @param request registration payload with name, email, password, optional role
     * @return AuthResponse containing the JWT and user details
     * @throws DuplicateEmailException if the email is already in use
     */
    @Transactional
    public AuthDTOs.AuthResponse register(AuthDTOs.RegisterRequest request) {
        logger.info("Attempting to register user with email: {}", request.getEmail());

        // Duplicate email check
        if (userRepository.existsByEmail(request.getEmail())) {
            logger.warn("Registration failed — email already exists: {}", request.getEmail());
            throw new DuplicateEmailException("Email is already registered: " + request.getEmail());
        }

        // Determine role — default to USER
        User.Role role = (request.getRole() != null) ? request.getRole() : User.Role.USER;

        // Build and persist the user entity
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(role)
                .build();

        userRepository.save(user);
        logger.info("User registered successfully: {} with role: {}", user.getEmail(), user.getRole());

        // Issue JWT
        String token = jwtUtils.generateToken(user.getEmail(), user.getRole().name());
        return new AuthDTOs.AuthResponse(token, user.getEmail(), user.getName(), user.getRole().name());
    }

    /**
     * Authenticates a user and returns a signed JWT.
     *
     * @param request login payload with email and password
     * @return AuthResponse containing the JWT and user details
     * @throws InvalidCredentialsException if email not found or password mismatch
     */
    @Transactional(readOnly = true)
    public AuthDTOs.AuthResponse login(AuthDTOs.LoginRequest request) {
        logger.info("Login attempt for email: {}", request.getEmail());

        // Fetch user — throw typed exception if not found
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    logger.warn("Login failed — user not found: {}", request.getEmail());
                    return new InvalidCredentialsException("Invalid email or password");
                });

        // Validate password against BCrypt hash
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            logger.warn("Login failed — invalid password for: {}", request.getEmail());
            throw new InvalidCredentialsException("Invalid email or password");
        }

        logger.info("Login successful for: {} (role: {})", user.getEmail(), user.getRole());
        String token = jwtUtils.generateToken(user.getEmail(), user.getRole().name());
        return new AuthDTOs.AuthResponse(token, user.getEmail(), user.getName(), user.getRole().name());
    }
}
