package com.smartcomplaint.auth.controller;

import com.smartcomplaint.auth.dto.AuthDTOs;
import com.smartcomplaint.auth.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for authentication operations.
 * All routes are public (no JWT required) as configured in SecurityConfig.
 * Accessible via API Gateway at: POST /api/auth/register, POST /api/auth/login
 */
@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
@Tag(name = "Authentication", description = "User registration, login, and JWT issuance")
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @Operation(summary = "Register a new user",
               description = "Creates a new user account and returns a JWT token. Role defaults to USER.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "User registered successfully",
                     content = @Content(schema = @Schema(implementation = AuthDTOs.AuthResponse.class))),
        @ApiResponse(responseCode = "400", description = "Validation error"),
        @ApiResponse(responseCode = "409", description = "Email already registered")
    })
    @PostMapping("/register")
    public ResponseEntity<AuthDTOs.AuthResponse> register(
            @Valid @RequestBody AuthDTOs.RegisterRequest request) {
        logger.info("POST /auth/register - registering user: {}", request.getEmail());
        return ResponseEntity.ok(authService.register(request));
    }

    @Operation(summary = "Login",
               description = "Authenticates credentials and returns a JWT Bearer token.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Login successful",
                     content = @Content(schema = @Schema(implementation = AuthDTOs.AuthResponse.class))),
        @ApiResponse(responseCode = "400", description = "Validation error"),
        @ApiResponse(responseCode = "401", description = "Invalid credentials")
    })
    @PostMapping("/login")
    public ResponseEntity<AuthDTOs.AuthResponse> login(
            @Valid @RequestBody AuthDTOs.LoginRequest request) {
        logger.info("POST /auth/login - attempt for: {}", request.getEmail());
        return ResponseEntity.ok(authService.login(request));
    }

    @Operation(summary = "Health check", description = "Returns service status")
    @GetMapping("/health")
    public ResponseEntity<AuthDTOs.ApiResponse> health() {
        return ResponseEntity.ok(new AuthDTOs.ApiResponse("Auth Service is running", true));
    }
}
