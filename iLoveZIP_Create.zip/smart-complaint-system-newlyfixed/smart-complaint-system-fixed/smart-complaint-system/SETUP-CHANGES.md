# Changes: Real Notifications + Persistent Databases

## What changed

### 1. Real email notifications (`notification-service`)

`NotificationService.java` — replaced `simulateDelivery()` with actual SMTP
delivery via Spring's `JavaMailSender`. On success → status `SENT`, on
`MailException` → status `FAILED` (logged, non-fatal; ticket ops still succeed).

`pom.xml` — added `spring-boot-starter-mail`.

### 2. Persistent file-based H2 databases (all 4 services)

| Service              | Old (in-memory, lost on restart)            | New (file-based, persists)                              |
|----------------------|---------------------------------------------|---------------------------------------------------------|
| auth-service         | `jdbc:h2:mem:authdb`                        | `jdbc:h2:file:./data/authdb`                            |
| ticket-service       | `jdbc:h2:mem:ticketdb`                      | `jdbc:h2:file:./data/ticketdb`                          |
| notification-service | `jdbc:h2:mem:notificationdb`                | `jdbc:h2:file:./data/notificationdb`                    |
| agent-service        | `jdbc:h2:mem:agentdb`                       | `jdbc:h2:file:./data/agentdb`                           |

`ddl-auto` changed from `create-drop` → `update` so schema is preserved across
restarts. Switch to `validate` once your schema is stable in production.

Each service writes its `.mv.db` file under its own `./data/` directory
(relative to the working directory when launched).

---

## Required setup before running

### SMTP credentials (notification-service)

Set these environment variables (or add an `application-local.yml` that is
git-ignored):

```bash
export MAIL_HOST=smtp.gmail.com        # or your SMTP host
export MAIL_PORT=587
export MAIL_USERNAME=you@gmail.com
export MAIL_PASSWORD=your-app-password # Gmail: use an App Password, not your real password
export MAIL_FROM=no-reply@yourapp.com
```

**Gmail quick start:**
1. Enable 2FA on your Google account.
2. Go to Google Account → Security → App Passwords.
3. Generate an app password for "Mail".
4. Use that 16-char password as `MAIL_PASSWORD`.

**Other providers:** Adjust `MAIL_HOST` and `MAIL_PORT` accordingly
(e.g. Outlook: `smtp.office365.com:587`, SendGrid: `smtp.sendgrid.net:587`).

### Data directories

Each service auto-creates `./data/` on first start. If you run services from
their own folders (e.g. `cd ticket-service && java -jar target/...`), the DB
files live at `ticket-service/data/ticketdb.mv.db`. Back these up if needed.

---

## No other breaking changes

All existing APIs, DTOs, Eureka registration, JWT config, and OpenAPI docs are
unchanged.
