# SmartComplaint System

A production-grade microservices complaint management platform built with Spring Boot 3, Spring Cloud, and Spring Security.

## Architecture

```
Browser / Postman / Swagger
         │
    ┌────▼────┐
    │   API   │  :8080  (Spring Cloud Gateway + JWT filter)
    │ Gateway │
    └────┬────┘
         │ routes via Eureka
   ┌─────┼────────────────┐
   │     │                │
┌──▼──┐ ┌▼──────┐ ┌──────▼────────┐ ┌──────────────┐
│Auth │ │Ticket │ │Notification   │ │Agent Service │
│:8081│ │:8082  │ │Service :8083  │ │:8084         │
└──┬──┘ └───┬───┘ └───────────────┘ └──────────────┘
   │        │ fires async notification via WebClient
   │        └─────────────────────────────────────────►
   │
 authdb  ticketdb   notificationdb   agentdb
 (H2/MySQL)
```

**Services:**
| Service | Port | Description |
|---------|------|-------------|
| Eureka Server | 8761 | Service discovery registry |
| API Gateway | 8080 | JWT auth, routing, CORS |
| Auth Service | 8081 | Register/Login → JWT |
| Ticket Service | 8082 | Complaint CRUD + status updates |
| Notification Service | 8083 | Email delivery + audit log |
| Agent Service | 8084 | Agent management + ticket assignment |

---

## Quick Start (H2 in-memory — no DB setup needed)

```bash
# 1. Clone / extract the project
cd smart-complaint-system

# 2. (Optional) Configure email in .env
cp .env.example .env
# Edit .env: set MAIL_USERNAME, MAIL_PASSWORD (Gmail App Password)

# 3. Start everything
./start-all.sh

# 4. Open the frontend
open frontend/index.html   # macOS
xdg-open frontend/index.html  # Linux
```

---

## MySQL Setup

```bash
# 1. Run the setup SQL
mysql -u root -p < docs/mysql-setup.sql

# 2. Configure .env
cp .env.example .env
# Edit .env: set DB_USERNAME, DB_PASSWORD, MAIL_* variables

# 3. Start with MySQL profile
./start-all.sh --mysql
```

---

## Email Notifications

Notifications are sent to the **recipient's email address** (the user who submitted the ticket).

To enable real email delivery:
1. Use a Gmail account
2. Enable 2FA → generate an **App Password** at https://myaccount.google.com/apppasswords
3. Set in `.env`:
```
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-16-char-app-password
MAIL_FROM=your-email@gmail.com
```

**Events that trigger emails:**
- `TICKET_CREATED` — when a user submits a complaint
- `STATUS_UPDATED` — when ticket status changes (OPEN → IN_PROGRESS → RESOLVED)
- `AGENT_ASSIGNED` — when an agent is assigned to a ticket

If email is not configured, notifications are saved to the DB with `FAILED` status — the rest of the app works normally.

---

## Swagger UI (per service)

Access Swagger directly on each service (no auth needed for Swagger itself):

| Service | Swagger URL |
|---------|-------------|
| Auth | http://localhost:8081/swagger-ui.html |
| Ticket | http://localhost:8082/swagger-ui.html |
| Notification | http://localhost:8083/swagger-ui.html |
| Agent | http://localhost:8084/swagger-ui.html |

**To test protected endpoints in Swagger:**
1. Call `POST /auth/login` → copy the `token` from the response
2. Click **Authorize** (🔒) at the top right
3. Enter `Bearer <your-token>` and click Authorize

---

## Postman

Import: `docs/SmartComplaintSystem.postman_collection.json`

The collection uses `{{base_url}}` (default: `http://localhost:8080/api`) and `{{token}}` variables.

**Auto-token capture:** Login and Register requests automatically save the JWT to `{{token}}` via test scripts. Just run Register or Login first, and all subsequent requests will be authenticated.

---

## H2 Console (dev mode only)

Access in-memory databases at:

| Service | URL | JDBC URL |
|---------|-----|----------|
| Auth | http://localhost:8081/h2-console | `jdbc:h2:mem:authdb` |
| Ticket | http://localhost:8082/h2-console | `jdbc:h2:mem:ticketdb` |
| Notification | http://localhost:8083/h2-console | `jdbc:h2:mem:notificationdb` |
| Agent | http://localhost:8084/h2-console | `jdbc:h2:mem:agentdb` |

Username: `sa`, Password: (empty)

---

## Roles

| Role | Can do |
|------|--------|
| `USER` | Register, login, submit tickets, view own tickets, view own notifications |
| `AGENT` | All USER actions + view all tickets, update ticket status, assign tickets |
| `ADMIN` | All AGENT actions + manage agents, view all notifications |

---

## API Reference (via Gateway at :8080)

### Auth
```
POST /api/auth/register   → { name, email, password, role? }
POST /api/auth/login      → { email, password }
GET  /api/auth/health
```

### Tickets (requires Bearer token)
```
POST   /api/tickets             → Create ticket
GET    /api/tickets             → All tickets (AGENT/ADMIN)
GET    /api/tickets/my          → My tickets
GET    /api/tickets/{id}        → Ticket by ID
PATCH  /api/tickets/{id}/status → Update status
PATCH  /api/tickets/{id}/assign/{agentEmail}
GET    /api/tickets/status/{status}
GET    /api/tickets/unassigned
```

### Notifications (requires Bearer token)
```
POST /api/notifications/send            → Send notification (internal)
GET  /api/notifications                 → All notifications (admin)
GET  /api/notifications/user/{email}    → By recipient
GET  /api/notifications/ticket/{id}     → By ticket
GET  /api/notifications/health
```

### Agents (requires Bearer token)
```
POST /api/agents                          → Register agent
GET  /api/agents                          → All agents
GET  /api/agents/{id}
GET  /api/agents/available
POST /api/agents/assign                   → Assign ticket to agent
POST /api/agents/auto-assign/{ticketId}
PATCH /api/agents/{id}/status
```

---

## Frontend

Open `frontend/index.html` directly in your browser (no build step needed).

The single-page app communicates with the API Gateway at `http://localhost:8080/api`.

**Features by role:**
- **USER**: Submit complaints, view ticket status, notifications inbox
- **AGENT**: Dashboard with all tickets, status updates, auto-assignment
- **ADMIN**: Full dashboard, agent management, notification audit log

---

## Stopping Services

```bash
./stop-all.sh
```
