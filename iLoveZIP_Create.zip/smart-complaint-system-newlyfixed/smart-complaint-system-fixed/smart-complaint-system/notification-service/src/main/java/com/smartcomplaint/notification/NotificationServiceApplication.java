package com.smartcomplaint.notification;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Notification Service — independent microservice for notification persistence and delivery simulation. */
@SpringBootApplication
public class NotificationServiceApplication {
    private static final Logger logger = LoggerFactory.getLogger(NotificationServiceApplication.class);
    public static void main(String[] args) {
        SpringApplication.run(NotificationServiceApplication.class, args);
        logger.info("Notification Service started on port 8083");
    }
}
