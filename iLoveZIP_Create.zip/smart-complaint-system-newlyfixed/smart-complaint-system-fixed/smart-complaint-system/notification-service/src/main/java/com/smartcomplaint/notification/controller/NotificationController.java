package com.smartcomplaint.notification.controller;

import com.smartcomplaint.notification.dto.NotificationDTOs;
import com.smartcomplaint.notification.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * Notification REST Controller.
 * /send is called internally by ticket-service and agent-service (via WebClient).
 * Other GET endpoints support admin auditing and user notification history.
 * Accessible via Gateway at: /api/notifications/**
 */
@RestController
@RequestMapping("/notifications")
@CrossOrigin(origins = "*")
@Tag(name = "Notifications", description = "Notification management and audit log")
@SecurityRequirement(name = "BearerAuth")
public class NotificationController {

    private static final Logger logger = LoggerFactory.getLogger(NotificationController.class);
    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @Operation(summary = "Send notification",
               description = "Internal endpoint — called by ticket-service/agent-service via WebClient")
    @PostMapping("/send")
    public ResponseEntity<NotificationDTOs.NotificationResponse> send(
            @Valid @RequestBody NotificationDTOs.SendNotificationRequest request) {
        logger.info("POST /notifications/send → {}", request.getToEmail());
        return ResponseEntity.ok(notificationService.sendNotification(request));
    }

    @Operation(summary = "Get all notifications (Admin audit view)")
    @GetMapping
    public ResponseEntity<List<NotificationDTOs.NotificationResponse>> getAll() {
        logger.info("GET /notifications");
        return ResponseEntity.ok(notificationService.getAll());
    }

    @Operation(summary = "Get notifications by recipient email")
    @GetMapping("/user/{email}")
    public ResponseEntity<List<NotificationDTOs.NotificationResponse>> getByEmail(
            @PathVariable String email) {
        logger.info("GET /notifications/user/{}", email);
        return ResponseEntity.ok(notificationService.getByEmail(email));
    }

    @Operation(summary = "Get notifications for a specific ticket")
    @GetMapping("/ticket/{ticketId}")
    public ResponseEntity<List<NotificationDTOs.NotificationResponse>> getByTicket(
            @PathVariable String ticketId) {
        logger.info("GET /notifications/ticket/{}", ticketId);
        return ResponseEntity.ok(notificationService.getByTicketId(ticketId));
    }

    @Operation(summary = "Health check")
    @GetMapping("/health")
    public ResponseEntity<NotificationDTOs.ApiResponse> health() {
        return ResponseEntity.ok(new NotificationDTOs.ApiResponse("Notification Service is running", true));
    }
}
