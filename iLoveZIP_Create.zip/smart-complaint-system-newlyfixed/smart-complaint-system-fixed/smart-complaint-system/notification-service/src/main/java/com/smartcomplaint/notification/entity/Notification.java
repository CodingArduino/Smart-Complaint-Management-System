package com.smartcomplaint.notification.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Notification entity — persists every notification in the notification-service's
 * dedicated H2 database. No shared DB with other microservices.
 */
@Entity
@Table(name = "notifications")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Notification {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String toEmail;

    @Column(nullable = false, length = 200)
    private String subject;

    @Column(nullable = false, length = 2000)
    private String body;

    /** Linked ticket ID (from ticket-service) — stored as string, no FK constraint */
    @Column(length = 20)
    private String ticketId;

    /** TICKET_CREATED | STATUS_UPDATED | AGENT_ASSIGNED */
    @Column(nullable = false, length = 50)
    private String eventType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private DeliveryStatus deliveryStatus;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
        if (this.deliveryStatus == null) this.deliveryStatus = DeliveryStatus.PENDING;
    }

    public enum DeliveryStatus { PENDING, SENT, FAILED }
}
