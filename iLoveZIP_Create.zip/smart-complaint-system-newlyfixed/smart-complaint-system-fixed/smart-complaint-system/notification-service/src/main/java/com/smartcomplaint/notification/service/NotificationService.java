package com.smartcomplaint.notification.service;

import com.smartcomplaint.notification.dto.NotificationDTOs;
import com.smartcomplaint.notification.entity.Notification;
import com.smartcomplaint.notification.repository.NotificationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Notification Service business logic.
 *
 * Responsibilities:
 * - Persist every notification event for audit trail
 * - Deliver real emails via JavaMailSender (SMTP) to the recipient's email
 * - Provide query endpoints for notification history
 */
@Service
public class NotificationService {

    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

    private final NotificationRepository notificationRepository;
    private final JavaMailSender mailSender;

    @Value("${spring.mail.from:${spring.mail.username:no-reply@smartcomplaint.com}}")
    private String fromAddress;

    @Value("${spring.mail.username:}")
    private String mailUsername;

    public NotificationService(NotificationRepository notificationRepository,
                                JavaMailSender mailSender) {
        this.notificationRepository = notificationRepository;
        this.mailSender = mailSender;
    }

    /**
     * Persists and delivers a notification via SMTP email to the recipient.
     * Called by ticket-service and agent-service via WebClient.
     */
    @Transactional
    public NotificationDTOs.NotificationResponse sendNotification(
            NotificationDTOs.SendNotificationRequest request) {
        logger.info("Processing notification → {} | event: {}", request.getToEmail(), request.getEventType());

        Notification notification = Notification.builder()
                .toEmail(request.getToEmail())
                .subject(request.getSubject())
                .body(request.getBody())
                .ticketId(request.getTicketId())
                .eventType(request.getEventType())
                .deliveryStatus(Notification.DeliveryStatus.PENDING)
                .build();

        Notification saved = notificationRepository.save(notification);

        // Attempt real email delivery to recipient
        deliverEmail(saved);

        logger.info("Notification #{} → {} to {}", saved.getId(), saved.getDeliveryStatus(), saved.getToEmail());
        return mapToResponse(saved);
    }

    /** Returns all notifications for a given recipient. */
    @Transactional(readOnly = true)
    public List<NotificationDTOs.NotificationResponse> getByEmail(String email) {
        return notificationRepository.findByToEmailOrderByCreatedAtDesc(email)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    /** Returns all notifications for a specific ticket. */
    @Transactional(readOnly = true)
    public List<NotificationDTOs.NotificationResponse> getByTicketId(String ticketId) {
        return notificationRepository.findByTicketIdOrderByCreatedAtDesc(ticketId)
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    /** Returns all notifications (admin view). */
    @Transactional(readOnly = true)
    public List<NotificationDTOs.NotificationResponse> getAll() {
        return notificationRepository.findAll()
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    /**
     * Delivers the email via SMTP to the recipient (toEmail).
     * Uses the configured MAIL_FROM or MAIL_USERNAME as the sender.
     * Marks status SENT on success, FAILED on error (non-blocking).
     */
    private void deliverEmail(Notification notification) {
        // Determine from address: prefer explicit MAIL_FROM, fall back to MAIL_USERNAME
        String from = (fromAddress != null && !fromAddress.isEmpty() && !fromAddress.startsWith("${"))
                ? fromAddress
                : (mailUsername != null && !mailUsername.isEmpty() ? mailUsername : "no-reply@smartcomplaint.com");

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(from);
            message.setTo(notification.getToEmail()); // Sends to the actual recipient email
            message.setSubject(notification.getSubject());
            message.setText(buildEmailBody(notification));
            mailSender.send(message);

            notification.setDeliveryStatus(Notification.DeliveryStatus.SENT);
            notificationRepository.save(notification);
            logger.info("Email delivered to {} for event {}", notification.getToEmail(), notification.getEventType());
        } catch (MailException ex) {
            notification.setDeliveryStatus(Notification.DeliveryStatus.FAILED);
            notificationRepository.save(notification);
            logger.error("Email delivery FAILED to {} — {}", notification.getToEmail(), ex.getMessage());
        }
    }

    /** Formats a clean, readable email body. */
    private String buildEmailBody(Notification notification) {
        return notification.getBody()
                + "\n\n"
                + "---\n"
                + "SmartComplaint System\n"
                + "This is an automated notification. Please do not reply to this email.\n"
                + (notification.getTicketId() != null
                    ? "Ticket ID: #" + notification.getTicketId() + "\n"
                    : "")
                + "Event: " + notification.getEventType();
    }

    private NotificationDTOs.NotificationResponse mapToResponse(Notification n) {
        NotificationDTOs.NotificationResponse r = new NotificationDTOs.NotificationResponse();
        r.setId(n.getId());
        r.setToEmail(n.getToEmail());
        r.setSubject(n.getSubject());
        r.setEventType(n.getEventType());
        r.setDeliveryStatus(n.getDeliveryStatus().name());
        r.setCreatedAt(n.getCreatedAt());
        return r;
    }
}
