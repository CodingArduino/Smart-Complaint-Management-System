package com.smartcomplaint.notification.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDateTime;

/** DTOs for Notification Service — decouples API contract from JPA entity. */
public class NotificationDTOs {

    @Data @NoArgsConstructor @AllArgsConstructor
    @Schema(description = "Payload to trigger a notification (sent by ticket-service or agent-service)")
    public static class SendNotificationRequest {

        @NotBlank(message = "Recipient email is required")
        @Email(message = "Valid recipient email required")
        @Schema(example = "user@example.com")
        private String toEmail;

        @NotBlank(message = "Subject is required")
        @Schema(example = "Ticket #12 Created")
        private String subject;

        @NotBlank(message = "Body is required")
        @Schema(example = "Your complaint has been submitted. Priority: HIGH")
        private String body;

        @Schema(example = "12")
        private String ticketId;

        @Schema(example = "TICKET_CREATED")
        private String eventType;
    }

    @Data @NoArgsConstructor
    @Schema(description = "Notification record returned by the API")
    public static class NotificationResponse {
        private Long id;
        private String toEmail;
        private String subject;
        private String eventType;
        private String deliveryStatus;
        private LocalDateTime createdAt;
    }

    @Data @AllArgsConstructor @NoArgsConstructor
    public static class ApiResponse {
        private String message;
        private boolean success;
    }
}
