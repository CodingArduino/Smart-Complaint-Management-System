package com.smartcomplaint.notification.repository;

import com.smartcomplaint.notification.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/** JPA repository for Notification — dedicated DB, no cross-service sharing. */
@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByToEmailOrderByCreatedAtDesc(String email);
    List<Notification> findByTicketIdOrderByCreatedAtDesc(String ticketId);
    List<Notification> findByEventTypeOrderByCreatedAtDesc(String eventType);
}
