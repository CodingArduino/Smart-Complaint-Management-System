package com.smartcomplaint.notification.service;

import com.smartcomplaint.notification.dto.NotificationDTOs;
import com.smartcomplaint.notification.entity.Notification;
import com.smartcomplaint.notification.repository.NotificationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationRepository notificationRepository;

    @InjectMocks
    private NotificationService notificationService;

    private Notification sampleNotification;

    @BeforeEach
    void setUp() {
        sampleNotification = Notification.builder()
                .id(1L).toEmail("user@example.com").subject("Test Subject")
                .body("Test Body").ticketId("5").eventType("TICKET_CREATED")
                .deliveryStatus(Notification.DeliveryStatus.SENT)
                .createdAt(LocalDateTime.now()).build();
    }

    @Test
    @DisplayName("sendNotification() - persists notification and marks SENT")
    void sendNotification_success() {
        NotificationDTOs.SendNotificationRequest req = new NotificationDTOs.SendNotificationRequest(
                "user@example.com", "Ticket #5 Created", "Your ticket was submitted", "5", "TICKET_CREATED");

        when(notificationRepository.save(any(Notification.class)))
                .thenReturn(sampleNotification);

        NotificationDTOs.NotificationResponse response = notificationService.sendNotification(req);

        assertThat(response.getToEmail()).isEqualTo("user@example.com");
        assertThat(response.getDeliveryStatus()).isEqualTo("SENT");
        // save called twice: initial persist + delivery status update
        verify(notificationRepository, times(2)).save(any(Notification.class));
    }

    @Test
    @DisplayName("getByEmail() - returns notifications for given email")
    void getByEmail_returnsList() {
        when(notificationRepository.findByToEmailOrderByCreatedAtDesc("user@example.com"))
                .thenReturn(List.of(sampleNotification));

        List<NotificationDTOs.NotificationResponse> result =
                notificationService.getByEmail("user@example.com");

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getEventType()).isEqualTo("TICKET_CREATED");
    }

    @Test
    @DisplayName("getByTicketId() - returns notifications for ticket")
    void getByTicketId_returnsList() {
        when(notificationRepository.findByTicketIdOrderByCreatedAtDesc("5"))
                .thenReturn(List.of(sampleNotification));

        List<NotificationDTOs.NotificationResponse> result = notificationService.getByTicketId("5");
        assertThat(result).hasSize(1);
    }
}
