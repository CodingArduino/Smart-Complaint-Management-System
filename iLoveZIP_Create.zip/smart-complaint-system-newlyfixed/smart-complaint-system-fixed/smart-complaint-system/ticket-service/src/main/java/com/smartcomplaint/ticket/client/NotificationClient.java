package com.smartcomplaint.ticket.client;

import com.smartcomplaint.ticket.dto.TicketDTOs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * Inter-service client — calls Notification Service asynchronously via WebClient.
 *
 * Uses reactive non-blocking I/O (subscribe pattern) so ticket operations
 * are not blocked waiting for notification delivery.
 *
 * Eureka load-balancing is applied via the "lb://" scheme in the base URL.
 */
@Component
public class NotificationClient {

    private static final Logger logger = LoggerFactory.getLogger(NotificationClient.class);

    private final WebClient webClient;

    public NotificationClient(WebClient.Builder webClientBuilder,
                               @Value("${services.notification.url}") String notificationServiceUrl) {
        this.webClient = webClientBuilder
                .baseUrl(notificationServiceUrl)
                .build();
    }

    /**
     * Sends a notification request to Notification Service asynchronously.
     * Errors are caught and logged — ticket operations succeed even if notification fails.
     *
     * @param payload notification details (recipient, subject, body, event type)
     */
    public void sendNotificationAsync(TicketDTOs.NotificationPayload payload) {
        logger.info("Sending async notification to {} for event: {}",
                payload.getToEmail(), payload.getEventType());

        webClient.post()
                .uri("/notifications/send")
                .body(Mono.just(payload), TicketDTOs.NotificationPayload.class)
                .retrieve()
                .bodyToMono(String.class)
                .doOnSuccess(response ->
                        logger.info("Notification sent successfully for ticket: {}", payload.getTicketId()))
                .doOnError(error ->
                        logger.warn("Notification failed for ticket {} (non-critical): {}",
                                payload.getTicketId(), error.getMessage()))
                // Subscribe fire-and-forget — doesn't block the calling thread
                .subscribe();
    }
}
