package com.smartcomplaint.ticket.controller;

import com.smartcomplaint.ticket.dto.TicketDTOs;
import com.smartcomplaint.ticket.entity.Ticket;
import com.smartcomplaint.ticket.service.TicketService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for ticket/complaint management.
 *
 * All routes require a valid JWT (enforced at Gateway level).
 * The API Gateway injects X-User-Email and X-User-Role headers after JWT validation —
 * controllers read these headers instead of parsing the token again.
 *
 * Accessible via Gateway at: /api/tickets/**
 */
@RestController
@RequestMapping("/tickets")
@CrossOrigin(origins = "*")
@Tag(name = "Tickets", description = "Complaint ticket lifecycle management")
@SecurityRequirement(name = "BearerAuth")
public class TicketController {

    private static final Logger logger = LoggerFactory.getLogger(TicketController.class);
    private static final String USER_EMAIL_HEADER = "X-User-Email";
    private static final String USER_ROLE_HEADER  = "X-User-Role";

    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @Operation(summary = "Submit a new complaint ticket",
               description = "Creates a ticket attributed to the authenticated user. Priority auto-assigned if omitted.")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Ticket created"),
        @ApiResponse(responseCode = "400", description = "Validation error"),
        @ApiResponse(responseCode = "401", description = "Unauthorized — missing or invalid JWT")
    })
    @PostMapping
    public ResponseEntity<TicketDTOs.TicketResponse> createTicket(
            @Valid @RequestBody TicketDTOs.CreateTicketRequest request,
            @Parameter(hidden = true) @RequestHeader(value = USER_EMAIL_HEADER, defaultValue = "anonymous@postman.test") String userEmail) {
        logger.info("POST /tickets | user: {}", userEmail);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ticketService.createTicket(request, userEmail));
    }

    @Operation(summary = "Get all tickets", description = "Returns all tickets. Intended for AGENT/ADMIN roles.")
    @GetMapping
    public ResponseEntity<List<TicketDTOs.TicketResponse>> getAllTickets() {
        logger.info("GET /tickets");
        return ResponseEntity.ok(ticketService.getAllTickets());
    }

    @Operation(summary = "Get ticket by ID")
    @GetMapping("/{id}")
    public ResponseEntity<TicketDTOs.TicketResponse> getTicketById(@PathVariable Long id) {
        logger.info("GET /tickets/{}", id);
        return ResponseEntity.ok(ticketService.getTicketById(id));
    }

    @Operation(summary = "Get my tickets", description = "Returns all tickets submitted by the authenticated user.")
    @GetMapping("/my")
    public ResponseEntity<List<TicketDTOs.TicketResponse>> getMyTickets(
            @Parameter(hidden = true) @RequestHeader(value = USER_EMAIL_HEADER, defaultValue = "anonymous@postman.test") String userEmail) {
        logger.info("GET /tickets/my | user: {}", userEmail);
        return ResponseEntity.ok(ticketService.getTicketsByEmail(userEmail));
    }

    @Operation(summary = "Get tickets by user email", description = "Admin/Agent use — filter by submitter email.")
    @GetMapping("/user/{email}")
    public ResponseEntity<List<TicketDTOs.TicketResponse>> getTicketsByEmail(
            @PathVariable String email) {
        logger.info("GET /tickets/user/{}", email);
        return ResponseEntity.ok(ticketService.getTicketsByEmail(email));
    }

    @Operation(summary = "Get tickets by status")
    @GetMapping("/status/{status}")
    public ResponseEntity<List<TicketDTOs.TicketResponse>> getTicketsByStatus(
            @PathVariable Ticket.Status status) {
        logger.info("GET /tickets/status/{}", status);
        return ResponseEntity.ok(ticketService.getTicketsByStatus(status));
    }

    @Operation(summary = "Get unassigned open tickets", description = "Used by agent-service to claim tickets.")
    @GetMapping("/unassigned")
    public ResponseEntity<List<TicketDTOs.TicketResponse>> getUnassignedTickets() {
        logger.info("GET /tickets/unassigned");
        return ResponseEntity.ok(ticketService.getUnassignedTickets());
    }

    @Operation(summary = "Update ticket status", description = "Agent/Admin updates ticket status and optionally assigns agent.")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Status updated"),
        @ApiResponse(responseCode = "404", description = "Ticket not found")
    })
    @RequestMapping(value = "/{id}/status", method = {org.springframework.web.bind.annotation.RequestMethod.PATCH, org.springframework.web.bind.annotation.RequestMethod.PUT})
    public ResponseEntity<TicketDTOs.TicketResponse> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody TicketDTOs.UpdateStatusRequest request,
            @Parameter(hidden = true) @RequestHeader(value = USER_ROLE_HEADER, defaultValue = "USER") String userRole) {
        logger.info("PATCH /tickets/{}/status | role: {}", id, userRole);
        return ResponseEntity.ok(ticketService.updateStatus(id, request));
    }

    @Operation(summary = "Assign ticket to agent")
    @RequestMapping(value = "/{id}/assign/{agentEmail}", method = {org.springframework.web.bind.annotation.RequestMethod.PATCH, org.springframework.web.bind.annotation.RequestMethod.PUT})
    public ResponseEntity<TicketDTOs.TicketResponse> assignTicket(
            @PathVariable Long id,
            @PathVariable String agentEmail) {
        logger.info("PATCH /tickets/{}/assign/{}", id, agentEmail);
        return ResponseEntity.ok(ticketService.assignTicket(id, agentEmail));
    }

    @Operation(summary = "Health check")
    @GetMapping("/health")
    public ResponseEntity<TicketDTOs.ApiResponse> health() {
        return ResponseEntity.ok(new TicketDTOs.ApiResponse("Ticket Service is running", true));
    }
}
