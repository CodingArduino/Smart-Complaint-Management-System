package com.smartcomplaint.ticket.dto;

import com.smartcomplaint.ticket.entity.Ticket;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DTOs for Ticket Service — separates API contract from JPA entity.
 * Using DTOs follows the SOLID principle of interface segregation and avoids
 * exposing internal entity fields over the API.
 */
public class TicketDTOs {

    @Data
    @NoArgsConstructor
    @Schema(description = "Payload to create a new ticket")
    public static class CreateTicketRequest {

        @NotBlank(message = "Title is required")
        @Size(min = 5, max = 200, message = "Title must be between 5 and 200 characters")
        @Schema(description = "Short summary of the issue", example = "App crashes on login")
        private String title;

        @NotBlank(message = "Description is required")
        @Size(min = 10, max = 2000, message = "Description must be between 10 and 2000 characters")
        @Schema(description = "Detailed description of the issue", example = "The mobile app throws a NullPointerException...")
        private String description;

        @NotNull(message = "Category is required")
        @Schema(description = "Ticket category", example = "TECHNICAL")
        private Ticket.Category category;

        /**
         * Priority is optional — auto-assigned via keyword matching if omitted.
         * Words like 'urgent', 'critical', 'down' → CRITICAL; 'error', 'fail' → HIGH; etc.
         */
        @Schema(description = "Priority (optional — auto-assigned from description keywords)", example = "HIGH")
        private Ticket.Priority priority;
    }

    @Data
    @NoArgsConstructor
    @Schema(description = "Request to update ticket status")
    public static class UpdateStatusRequest {

        @NotNull(message = "Status is required")
        @Schema(description = "New ticket status", example = "IN_PROGRESS")
        private Ticket.Status status;

        @Schema(description = "Agent email performing the update")
        private String agentEmail;
    }

    @Data
    @NoArgsConstructor
    @Schema(description = "Ticket details returned by the API")
    public static class TicketResponse {
        private Long id;
        private String title;
        private String description;
        private String submittedByEmail;
        private String assignedAgentEmail;
        private String category;
        private String priority;
        private String status;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
        private LocalDateTime resolvedAt;

        /** Maps a Ticket entity to a TicketResponse DTO */
        public static TicketResponse from(Ticket ticket) {
            TicketResponse r = new TicketResponse();
            r.id                 = ticket.getId();
            r.title              = ticket.getTitle();
            r.description        = ticket.getDescription();
            r.submittedByEmail   = ticket.getSubmittedByEmail();
            r.assignedAgentEmail = ticket.getAssignedAgentEmail();
            r.category           = ticket.getCategory().name();
            r.priority           = ticket.getPriority().name();
            r.status             = ticket.getStatus().name();
            r.createdAt          = ticket.getCreatedAt();
            r.updatedAt          = ticket.getUpdatedAt();
            r.resolvedAt         = ticket.getResolvedAt();
            return r;
        }
    }

    @Data
    @NoArgsConstructor
    public static class ApiResponse {
        private String message;
        private boolean success;

        public ApiResponse(String message, boolean success) {
            this.message = message;
            this.success = success;
        }
    }

    /** Lightweight payload sent to notification-service when a ticket changes */
    @Data
    @NoArgsConstructor
    public static class NotificationPayload {
        private String toEmail;
        private String subject;
        private String body;
        private String ticketId;
        private String eventType;

        public NotificationPayload(String toEmail, String subject, String body,
                                   String ticketId, String eventType) {
            this.toEmail   = toEmail;
            this.subject   = subject;
            this.body      = body;
            this.ticketId  = ticketId;
            this.eventType = eventType;
        }
    }
}
