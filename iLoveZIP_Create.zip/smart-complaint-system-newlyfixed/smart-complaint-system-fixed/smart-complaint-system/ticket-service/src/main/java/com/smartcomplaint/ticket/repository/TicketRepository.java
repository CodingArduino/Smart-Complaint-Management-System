package com.smartcomplaint.ticket.repository;

import com.smartcomplaint.ticket.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * JPA Repository for Ticket entity.
 * Uses Spring Data method naming conventions for derived queries.
 */
@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

    /** Fetch all tickets submitted by a given user email */
    List<Ticket> findBySubmittedByEmailOrderByCreatedAtDesc(String email);

    /** Fetch all tickets with a specific status */
    List<Ticket> findByStatusOrderByCreatedAtDesc(Ticket.Status status);

    /** Fetch all tickets assigned to a specific agent */
    List<Ticket> findByAssignedAgentEmailOrderByCreatedAtDesc(String agentEmail);

    /** Fetch tickets filtered by category */
    List<Ticket> findByCategoryOrderByPriorityDescCreatedAtDesc(Ticket.Category category);

    /** Count open tickets per user — used by analytics */
    @Query("SELECT COUNT(t) FROM Ticket t WHERE t.submittedByEmail = :email AND t.status = 'OPEN'")
    long countOpenTicketsByEmail(@Param("email") String email);

    /** Find all unassigned open tickets (for agent-service to pick up) */
    @Query("SELECT t FROM Ticket t WHERE t.assignedAgentEmail IS NULL AND t.status = 'OPEN' ORDER BY t.priority DESC, t.createdAt ASC")
    List<Ticket> findUnassignedOpenTickets();
}
