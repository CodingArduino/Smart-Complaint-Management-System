package com.smartcomplaint.ticket.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * WebClient configuration for Ticket Service.
 * The @LoadBalanced annotation enables Eureka-based service name resolution.
 * Usage: WebClient.Builder → resolves "http://notification-service" via Eureka registry.
 */
@Configuration
public class WebClientConfig {

    /**
     * Load-balanced WebClient.Builder.
     * When injected with @LoadBalanced, the builder resolves service names
     * (e.g., "http://notification-service") to real IP:port via Eureka.
     */
    @Bean
    @LoadBalanced
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }
}
