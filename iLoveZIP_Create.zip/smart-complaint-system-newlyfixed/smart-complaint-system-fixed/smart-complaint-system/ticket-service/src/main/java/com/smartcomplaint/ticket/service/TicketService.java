package com.smartcomplaint.ticket.service;

import com.smartcomplaint.ticket.client.NotificationClient;
import com.smartcomplaint.ticket.dto.TicketDTOs;
import com.smartcomplaint.ticket.entity.Ticket;
import com.smartcomplaint.ticket.exception.TicketNotFoundException;
import com.smartcomplaint.ticket.repository.TicketRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Business logic for ticket lifecycle management.
 *
 * Design decisions:
 * - Constructor injection for all dependencies (SOLID: DI)
 * - Typed exceptions (TicketNotFoundException) rather than raw RuntimeException
 * - Inter-service communication via non-blocking NotificationClient
 * - Keyword-based auto-priority assignment (extensible to ML model)
 * - All DB writes wrapped in @Transactional
 */
@Service
public class TicketService {

    private static final Logger logger = LoggerFactory.getLogger(TicketService.class);

    private final TicketRepository ticketRepository;
    private final NotificationClient notificationClient;

    public TicketService(TicketRepository ticketRepository,
                         NotificationClient notificationClient) {
        this.ticketRepository   = ticketRepository;
        this.notificationClient = notificationClient;
    }

    /**
     * Creates a new complaint ticket.
     * Priority is auto-assigned if not provided by the user.
     * Fires an async notification to Notification Service upon creation.
     *
     * @param request ticket payload from the client
     * @param userEmail resolved from JWT X-User-Email header (gateway-injected)
     * @return TicketResponse DTO
     */
    @Transactional
    public TicketDTOs.TicketResponse createTicket(TicketDTOs.CreateTicketRequest request,
                                                   String userEmail) {
        logger.info("Creating ticket for user: {} | category: {}", userEmail, request.getCategory());

        Ticket.Priority priority = (request.getPriority() != null)
                ? request.getPriority()
                : autoAssignPriority(request.getDescription());

        Ticket ticket = Ticket.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .submittedByEmail(userEmail)
                .category(request.getCategory())
                .priority(priority)
                .build();

        Ticket saved = ticketRepository.save(ticket);
        logger.info("Ticket created: ID={}, priority={}", saved.getId(), saved.getPriority());

        // Async notification — does not block ticket creation
        notificationClient.sendNotificationAsync(new TicketDTOs.NotificationPayload(
                userEmail,
                "Ticket #" + saved.getId() + " Created",
                "Your complaint has been submitted successfully. Priority: " + priority.name(),
                String.valueOf(saved.getId()),
                "TICKET_CREATED"
        ));

        return TicketDTOs.TicketResponse.from(saved);
    }

    /**
     * Returns all tickets — typically for ADMIN or AGENT use.
     */
    @Transactional(readOnly = true)
    public List<TicketDTOs.TicketResponse> getAllTickets() {
        logger.info("Fetching all tickets");
        return ticketRepository.findAll()
                .stream()
                .map(TicketDTOs.TicketResponse::from)
                .collect(Collectors.toList());
    }

    /**
     * Returns a single ticket by ID.
     *
     * @throws TicketNotFoundException if no ticket exists with the given ID
     */
    @Transactional(readOnly = true)
    public TicketDTOs.TicketResponse getTicketById(Long id) {
        logger.info("Fetching ticket ID: {}", id);
        Ticket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found with ID: " + id));
        return TicketDTOs.TicketResponse.from(ticket);
    }

    /**
     * Returns all tickets submitted by a specific user email.
     */
    @Transactional(readOnly = true)
    public List<TicketDTOs.TicketResponse> getTicketsByEmail(String email) {
        logger.info("Fetching tickets for user: {}", email);
        return ticketRepository.findBySubmittedByEmailOrderByCreatedAtDesc(email)
                .stream()
                .map(TicketDTOs.TicketResponse::from)
                .collect(Collectors.toList());
    }

    /**
     * Returns all tickets with a given status.
     */
    @Transactional(readOnly = true)
    public List<TicketDTOs.TicketResponse> getTicketsByStatus(Ticket.Status status) {
        logger.info("Fetching tickets with status: {}", status);
        return ticketRepository.findByStatusOrderByCreatedAtDesc(status)
                .stream()
                .map(TicketDTOs.TicketResponse::from)
                .collect(Collectors.toList());
    }

    /**
     * Updates the status of a ticket (e.g., OPEN → IN_PROGRESS → RESOLVED).
     * Fires an async notification to the ticket submitter upon status change.
     *
     * @param id     ticket ID
     * @param request new status + optional agent email
     * @return updated TicketResponse DTO
     * @throws TicketNotFoundException if the ticket does not exist
     */
    @Transactional
    public TicketDTOs.TicketResponse updateStatus(Long id, TicketDTOs.UpdateStatusRequest request) {
        logger.info("Updating ticket ID: {} → status: {}", id, request.getStatus());

        Ticket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found with ID: " + id));

        Ticket.Status oldStatus = ticket.getStatus();
        ticket.setStatus(request.getStatus());

        if (request.getAgentEmail() != null) {
            ticket.setAssignedAgentEmail(request.getAgentEmail());
        }

        Ticket updated = ticketRepository.save(ticket);
        logger.info("Ticket {} status changed: {} → {}", id, oldStatus, request.getStatus());

        // Notify the submitter of the status change
        notificationClient.sendNotificationAsync(new TicketDTOs.NotificationPayload(
                updated.getSubmittedByEmail(),
                "Ticket #" + id + " Status Updated",
                "Your ticket status has changed from " + oldStatus + " to " + request.getStatus(),
                String.valueOf(id),
                "STATUS_UPDATED"
        ));

        return TicketDTOs.TicketResponse.from(updated);
    }

    /**
     * Assigns a ticket to an agent.
     *
     * @param id         ticket ID
     * @param agentEmail email of the agent being assigned
     * @return updated TicketResponse
     */
    @Transactional
    public TicketDTOs.TicketResponse assignTicket(Long id, String agentEmail) {
        logger.info("Assigning ticket ID: {} to agent: {}", id, agentEmail);

        Ticket ticket = ticketRepository.findById(id)
                .orElseThrow(() -> new TicketNotFoundException("Ticket not found with ID: " + id));

        ticket.setAssignedAgentEmail(agentEmail);
        ticket.setStatus(Ticket.Status.IN_PROGRESS);
        Ticket updated = ticketRepository.save(ticket);

        logger.info("Ticket {} assigned to agent: {}", id, agentEmail);
        return TicketDTOs.TicketResponse.from(updated);
    }

    /**
     * Returns all unassigned open tickets — used by agent-service to pick up work.
     */
    @Transactional(readOnly = true)
    public List<TicketDTOs.TicketResponse> getUnassignedTickets() {
        return ticketRepository.findUnassignedOpenTickets()
                .stream()
                .map(TicketDTOs.TicketResponse::from)
                .collect(Collectors.toList());
    }

    /**
     * Rule-based priority assignment based on keyword matching in the description.
     * Can be extended to call an ML microservice for smarter classification.
     *
     * Keywords:
     *   CRITICAL → "urgent", "critical", "down", "outage"
     *   HIGH     → "error", "fail", "broken", "crash"
     *   MEDIUM   → "slow", "issue", "problem", "delay"
     *   LOW      → everything else
     */
    private Ticket.Priority autoAssignPriority(String description) {
        String lower = description.toLowerCase();
        if (lower.contains("urgent") || lower.contains("critical")
                || lower.contains("down") || lower.contains("outage")) {
            return Ticket.Priority.CRITICAL;
        } else if (lower.contains("error") || lower.contains("fail")
                || lower.contains("broken") || lower.contains("crash")) {
            return Ticket.Priority.HIGH;
        } else if (lower.contains("slow") || lower.contains("issue")
                || lower.contains("problem") || lower.contains("delay")) {
            return Ticket.Priority.MEDIUM;
        }
        return Ticket.Priority.LOW;
    }
}
