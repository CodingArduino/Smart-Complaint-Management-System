package com.smartcomplaint.ticket;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ticket Service — manages the full lifecycle of customer complaint tickets.
 * Communicates with Notification Service (async WebClient) and Agent Service (REST).
 */
@SpringBootApplication
public class TicketServiceApplication {

    private static final Logger logger = LoggerFactory.getLogger(TicketServiceApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(TicketServiceApplication.class, args);
        logger.info("Ticket Service started successfully on port 8082");
    }
}
