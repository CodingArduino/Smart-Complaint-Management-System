package com.smartcomplaint.ticket.service;

import com.smartcomplaint.ticket.client.NotificationClient;
import com.smartcomplaint.ticket.dto.TicketDTOs;
import com.smartcomplaint.ticket.entity.Ticket;
import com.smartcomplaint.ticket.exception.TicketNotFoundException;
import com.smartcomplaint.ticket.repository.TicketRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for TicketService — JUnit 5 + Mockito.
 * All external dependencies (repository, notification client) are mocked.
 */
@ExtendWith(MockitoExtension.class)
class TicketServiceTest {

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private NotificationClient notificationClient;

    @InjectMocks
    private TicketService ticketService;

    private Ticket sampleTicket;

    @BeforeEach
    void setUp() {
        sampleTicket = Ticket.builder()
                .id(1L)
                .title("App crashes on login")
                .description("The app throws an error when logging in")
                .submittedByEmail("user@example.com")
                .category(Ticket.Category.TECHNICAL)
                .priority(Ticket.Priority.HIGH)
                .status(Ticket.Status.OPEN)
                .build();
    }

    @Test
    @DisplayName("createTicket() - success: saves ticket and fires notification")
    void createTicket_success() {
        TicketDTOs.CreateTicketRequest request = new TicketDTOs.CreateTicketRequest();
        request.setTitle("App crashes on login");
        request.setDescription("The app throws an error when logging in");
        request.setCategory(Ticket.Category.TECHNICAL);

        when(ticketRepository.save(any(Ticket.class))).thenReturn(sampleTicket);
        doNothing().when(notificationClient).sendNotificationAsync(any());

        TicketDTOs.TicketResponse response = ticketService.createTicket(request, "user@example.com");

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getStatus()).isEqualTo("OPEN");
        assertThat(response.getPriority()).isEqualTo("HIGH");
        verify(ticketRepository, times(1)).save(any(Ticket.class));
        verify(notificationClient, times(1)).sendNotificationAsync(any());
    }

    @Test
    @DisplayName("createTicket() - auto priority CRITICAL for 'urgent' keyword")
    void createTicket_autoPriority_critical() {
        TicketDTOs.CreateTicketRequest request = new TicketDTOs.CreateTicketRequest();
        request.setTitle("URGENT outage");
        request.setDescription("System is down and urgent fix needed");
        request.setCategory(Ticket.Category.TECHNICAL);
        // priority intentionally null — should auto-assign

        Ticket criticalTicket = Ticket.builder().id(2L).priority(Ticket.Priority.CRITICAL)
                .status(Ticket.Status.OPEN).category(Ticket.Category.TECHNICAL)
                .title("URGENT outage").description("desc").submittedByEmail("u@e.com").build();
        when(ticketRepository.save(any())).thenReturn(criticalTicket);
        doNothing().when(notificationClient).sendNotificationAsync(any());

        TicketDTOs.TicketResponse response = ticketService.createTicket(request, "u@e.com");
        assertThat(response.getPriority()).isEqualTo("CRITICAL");
    }

    @Test
    @DisplayName("getTicketById() - found: returns TicketResponse")
    void getTicketById_found() {
        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));

        TicketDTOs.TicketResponse response = ticketService.getTicketById(1L);

        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getTitle()).isEqualTo("App crashes on login");
    }

    @Test
    @DisplayName("getTicketById() - not found: throws TicketNotFoundException")
    void getTicketById_notFound() {
        when(ticketRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> ticketService.getTicketById(99L))
                .isInstanceOf(TicketNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    @DisplayName("updateStatus() - success: updates status and notifies")
    void updateStatus_success() {
        TicketDTOs.UpdateStatusRequest req = new TicketDTOs.UpdateStatusRequest();
        req.setStatus(Ticket.Status.IN_PROGRESS);

        Ticket updated = Ticket.builder().id(1L).title("T").description("D")
                .submittedByEmail("u@e.com").category(Ticket.Category.GENERAL)
                .priority(Ticket.Priority.LOW).status(Ticket.Status.IN_PROGRESS).build();

        when(ticketRepository.findById(1L)).thenReturn(Optional.of(sampleTicket));
        when(ticketRepository.save(any())).thenReturn(updated);
        doNothing().when(notificationClient).sendNotificationAsync(any());

        TicketDTOs.TicketResponse response = ticketService.updateStatus(1L, req);
        assertThat(response.getStatus()).isEqualTo("IN_PROGRESS");
        verify(notificationClient).sendNotificationAsync(any());
    }

    @Test
    @DisplayName("getAllTickets() - returns list of all tickets")
    void getAllTickets_returnsList() {
        when(ticketRepository.findAll()).thenReturn(List.of(sampleTicket));

        List<TicketDTOs.TicketResponse> result = ticketService.getAllTickets();

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getSubmittedByEmail()).isEqualTo("user@example.com");
    }
}
