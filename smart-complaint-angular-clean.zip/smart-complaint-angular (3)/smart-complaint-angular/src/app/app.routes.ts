import { Routes } from '@angular/router';
import { authGuard, publicGuard } from './core/auth/auth.guards';
import { LayoutComponent } from './shared/layout/layout.component';

export const routes: Routes = [
  // Public — equivalent of <PublicRoute><LoginPage/></PublicRoute> etc.
  {
    path: 'login',
    canActivate: [publicGuard],
    loadComponent: () => import('./features/auth/login.component').then(m => m.LoginComponent),
  },
  {
    path: 'register',
    canActivate: [publicGuard],
    loadComponent: () => import('./features/auth/register.component').then(m => m.RegisterComponent),
  },

  // Protected — wrapped in Layout, equivalent of <ProtectedRoute><Layout>...</Layout></ProtectedRoute>
  {
    path: '',
    component: LayoutComponent,
    canActivate: [authGuard],
    canActivateChild: [authGuard],
    children: [
      {
        path: 'dashboard',
        loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent),
      },
      {
        path: 'tickets',
        data: { roles: ['AGENT', 'ADMIN'] },
        loadComponent: () => import('./features/tickets/tickets.component').then(m => m.TicketsComponent),
      },
      {
        path: 'tickets/:id',
        loadComponent: () => import('./features/tickets/ticket-detail.component').then(m => m.TicketDetailComponent),
      },
      {
        path: 'my-tickets',
        data: { roles: ['USER'] },
        loadComponent: () => import('./features/tickets/my-tickets.component').then(m => m.MyTicketsComponent),
      },
      {
        path: 'agents',
        data: { roles: ['AGENT', 'ADMIN'] },
        loadComponent: () => import('./features/agents/agents.component').then(m => m.AgentsComponent),
      },
      {
        path: 'notifications',
        data: { roles: ['ADMIN'] },
        loadComponent: () => import('./features/notifications/notifications.component').then(m => m.NotificationsComponent),
      },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
    ],
  },

  // Default redirect — equivalent of the catch-all <Navigate to="/dashboard" replace />
  { path: '**', redirectTo: 'dashboard' },
];
