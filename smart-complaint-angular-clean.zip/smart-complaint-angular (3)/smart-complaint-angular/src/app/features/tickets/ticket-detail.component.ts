import { CommonModule, Location } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { TicketApiService } from '../../core/services/ticket-api.service';
import { AgentApiService } from '../../core/services/agent-api.service';
import { Agent, Ticket, TicketStatus } from '../../core/models/types';

import { CardComponent } from '../../shared/ui/card/card.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { SpinnerComponent } from '../../shared/ui/spinner/spinner.component';
import { EmptyComponent } from '../../shared/ui/empty/empty.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { CategoryBadgeComponent, PriorityBadgeComponent, StatusBadgeComponent } from '../../shared/ui/badge/badge.component';

interface TimelineEvent {
  label: string;
  date?: string;
  icon: string;
  show: boolean;
}

@Component({
  selector: 'app-ticket-detail',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    CardComponent,
    AlertComponent,
    SpinnerComponent,
    EmptyComponent,
    ButtonComponent,
    InputComponent,
    CategoryBadgeComponent,
    PriorityBadgeComponent,
    StatusBadgeComponent,
  ],
  templateUrl: './ticket-detail.component.html',
  styleUrl: './ticket-detail.component.css',
})
export class TicketDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private location = inject(Location);
  private auth = inject(AuthService);
  private ticketApi = inject(TicketApiService);
  private agentApi = inject(AgentApiService);

  user = this.auth.user;

  ticket: Ticket | null = null;
  agents: Agent[] = [];
  loading = true;
  updating = false;
  error = '';
  success = '';

  statusForm = { status: '', agentEmail: '' };
  statusOptions = [...TicketStatus].map(s => ({ value: s, label: s.replace('_', ' ') }));

  get id(): string {
    return this.route.snapshot.paramMap.get('id') || '';
  }

  get isAgent(): boolean {
    return this.user()?.role === 'AGENT';
  }

  get isAdmin(): boolean {
    return this.user()?.role === 'ADMIN';
  }

  get isStaff(): boolean {
    return this.isAgent || this.isAdmin;
  }

  get isAssignedToMe(): boolean {
    return this.ticket?.assignedAgentEmail === this.user()?.email;
  }

  get agentOptions() {
    return this.agents.map(a => ({ value: a.email, label: `${a.name} (${a.specialization})` }));
  }

  get timeline(): TimelineEvent[] {
    if (!this.ticket) return [];
    return [
      { label: 'Submitted', date: this.ticket.createdAt, icon: '🎫', show: true },
      { label: 'Last Update', date: this.ticket.updatedAt, icon: '✏️', show: !!this.ticket.updatedAt },
      { label: 'Resolved', date: this.ticket.resolvedAt, icon: '✅', show: !!this.ticket.resolvedAt },
    ].filter(e => e.show);
  }

  ngOnInit() {
    this.fetchTicket();
  }

  async fetchTicket() {
    this.loading = true;
    try {
      const [tResult, aResult] = await Promise.allSettled([
        this.ticketApi.getById(this.id),
        this.isAdmin ? this.agentApi.getAvailable() : Promise.resolve([] as Agent[]),
      ]);

      if (tResult.status === 'fulfilled') {
        this.ticket = tResult.value;
        this.statusForm = {
          status: tResult.value.status,
          agentEmail: this.isAdmin ? tResult.value.assignedAgentEmail || '' : '',
        };
      }

      if (aResult.status === 'fulfilled') {
        this.agents = aResult.value;
      }
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }

  async handleStatusUpdate() {
    if (!this.ticket) return;
    this.updating = true;
    this.error = '';
    this.success = '';

    try {
      const payload: { status: string; agentEmail?: string } = { status: this.statusForm.status };
      if (this.isAdmin) payload.agentEmail = this.statusForm.agentEmail || undefined;

      this.ticket = await this.ticketApi.updateStatus(this.id, payload);
      this.success = 'Status updated successfully';
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.updating = false;
    }
  }

  async handleAssignToMe() {
    if (!this.ticket) return;
    this.updating = true;
    this.error = '';
    this.success = '';

    try {
      this.ticket = await this.ticketApi.updateStatus(this.id, {
        status: this.statusForm.status || this.ticket.status,
        agentEmail: this.user()?.email,
      });
      this.success = 'Ticket assigned to you';
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.updating = false;
    }
  }

  async handleAutoAssign() {
    if (!this.ticket) return;
    this.updating = true;
    this.error = '';
    this.success = '';

    try {
      await this.agentApi.autoAssign(this.id, this.ticket.category);
      await this.fetchTicket();
      this.success = 'Auto-assigned to best available agent';
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.updating = false;
    }
  }

  goBack() {
    this.location.back();
  }
}
