import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Ticket } from '../../core/models/types';
import { CardComponent } from '../../shared/ui/card/card.component';
import { CategoryBadgeComponent, StatusBadgeComponent, PriorityBadgeComponent } from '../../shared/ui/badge/badge.component';

@Component({
  selector: 'app-ticket-card',
  standalone: true,
  imports: [CommonModule, CardComponent, CategoryBadgeComponent, StatusBadgeComponent, PriorityBadgeComponent],
  template: `
    <app-card [hover]="true" (cardClick)="cardClick.emit()" class="ticket-card">
      <div>
        <div class="ticket-card-top">
          <span class="ticket-card-id">#{{ ticket.id }}</span>
          <app-category-badge [category]="ticket.category" />
        </div>
        <div class="ticket-card-title">{{ ticket.title }}</div>
        <div class="ticket-card-desc">
          {{ ticket.description.length > 120 ? ticket.description.slice(0, 120) + '…' : ticket.description }}
        </div>
        <div class="ticket-card-meta">
          {{ ticket.assignedAgentEmail ? 'Assigned to ' + ticket.assignedAgentEmail : 'Unassigned' }}
          · {{ ticket.createdAt | date }}
        </div>
      </div>
      <div class="ticket-card-badges">
        <app-status-badge [status]="ticket.status" />
        <app-priority-badge [priority]="ticket.priority" />
      </div>
    </app-card>
  `,
  styles: [
    `
      .ticket-card {
        display: grid;
      }
      ::ng-deep .ticket-card.app-card {
        display: grid;
        grid-template-columns: 1fr auto;
        align-items: start;
        gap: 16px;
      }
      .ticket-card-top {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 6px;
      }
      .ticket-card-id {
        font-size: 0.78rem;
        color: var(--text-3);
        font-family: var(--font-display);
      }
      .ticket-card-title {
        font-weight: 600;
        font-size: 0.95rem;
        color: var(--text);
        margin-bottom: 4px;
      }
      .ticket-card-desc {
        font-size: 0.82rem;
        color: var(--text-3);
        margin-bottom: 8px;
      }
      .ticket-card-meta {
        font-size: 0.78rem;
        color: var(--text-3);
      }
      .ticket-card-badges {
        display: flex;
        flex-direction: column;
        gap: 8px;
        align-items: flex-end;
      }
    `,
  ],
})
export class TicketCardComponent {
  @Input({ required: true }) ticket!: Ticket;
  @Output() cardClick = new EventEmitter<void>();
}
