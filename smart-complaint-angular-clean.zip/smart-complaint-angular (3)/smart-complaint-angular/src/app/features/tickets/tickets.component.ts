import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { TicketApiService } from '../../core/services/ticket-api.service';
import { Ticket, TicketCategory, TicketPriority, TicketStatus } from '../../core/models/types';

import { PageHeaderComponent } from '../../shared/ui/page-header/page-header.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { CardComponent } from '../../shared/ui/card/card.component';
import { EmptyComponent } from '../../shared/ui/empty/empty.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';
import { CategoryBadgeComponent, PriorityBadgeComponent, StatusBadgeComponent } from '../../shared/ui/badge/badge.component';
import { CreateTicketModalComponent } from './create-ticket-modal.component';

@Component({
  selector: 'app-tickets',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    PageHeaderComponent,
    AlertComponent,
    CardComponent,
    EmptyComponent,
    ButtonComponent,
    CategoryBadgeComponent,
    PriorityBadgeComponent,
    StatusBadgeComponent,
    CreateTicketModalComponent,
  ],
  templateUrl: './tickets.component.html',
  styleUrl: './tickets.component.css',
})
export class TicketsComponent implements OnInit {
  private auth = inject(AuthService);
  private ticketApi = inject(TicketApiService);
  private router = inject(Router);

  user = this.auth.user;

  tickets: Ticket[] = [];
  loading = true;
  error = '';
  showCreate = false;

  filter = { status: '', priority: '', category: '' };

  statusOptions = [...TicketStatus];
  priorityOptions = [...TicketPriority];
  categoryOptions = [...TicketCategory];

  ngOnInit() {
    this.fetchTickets();
  }

  async fetchTickets() {
    this.loading = true;
    try {
      this.tickets = await this.ticketApi.getAll();
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }

  get filtered(): Ticket[] {
    return this.tickets.filter(
      t =>
        (!this.filter.status || t.status === this.filter.status) &&
        (!this.filter.priority || t.priority === this.filter.priority) &&
        (!this.filter.category || t.category === this.filter.category)
    );
  }

  get hasActiveFilter(): boolean {
    return !!(this.filter.status || this.filter.priority || this.filter.category);
  }

  clearFilters() {
    this.filter = { status: '', priority: '', category: '' };
  }

  goToDetail(id: number) {
    this.router.navigateByUrl(`/tickets/${id}`);
  }

  onCreated() {
    this.fetchTickets();
    this.showCreate = false;
  }
}
