import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { TicketApiService } from '../../core/services/ticket-api.service';
import { Ticket } from '../../core/models/types';

import { PageHeaderComponent } from '../../shared/ui/page-header/page-header.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';
import { SpinnerComponent } from '../../shared/ui/spinner/spinner.component';
import { EmptyComponent } from '../../shared/ui/empty/empty.component';
import { TicketCardComponent } from './ticket-card.component';
import { CreateTicketModalComponent } from './create-ticket-modal.component';

@Component({
  selector: 'app-my-tickets',
  standalone: true,
  imports: [CommonModule, PageHeaderComponent, ButtonComponent, SpinnerComponent, EmptyComponent, TicketCardComponent, CreateTicketModalComponent],
  templateUrl: './my-tickets.component.html',
})
export class MyTicketsComponent implements OnInit {
  private ticketApi = inject(TicketApiService);
  private router = inject(Router);

  tickets: Ticket[] = [];
  loading = true;
  showCreate = false;

  ngOnInit() {
    this.fetchMy();
  }

  async fetchMy() {
    this.loading = true;
    try {
      this.tickets = await this.ticketApi.getMy();
    } catch {
      /* mirrors the original's silent catch */
    } finally {
      this.loading = false;
    }
  }

  goToDetail(id: number) {
    this.router.navigateByUrl(`/tickets/${id}`);
  }

  onCreated() {
    this.fetchMy();
    this.showCreate = false;
  }
}
