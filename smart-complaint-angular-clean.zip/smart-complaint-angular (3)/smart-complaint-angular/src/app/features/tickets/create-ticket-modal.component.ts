import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Output, inject } from '@angular/core';
import { TicketApiService } from '../../core/services/ticket-api.service';
import { TicketCategory, TicketPriority } from '../../core/models/types';

import { ModalComponent } from '../../shared/ui/modal/modal.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';

@Component({
  selector: 'app-create-ticket-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, ModalComponent, AlertComponent, InputComponent, ButtonComponent],
  templateUrl: './create-ticket-modal.component.html',
  styleUrls: ['./ticket-forms-shared.css'],
})
export class CreateTicketModalComponent {
  private ticketApi = inject(TicketApiService);

  @Output() closed = new EventEmitter<void>();
  @Output() created = new EventEmitter<void>();

  categories = [...TicketCategory];
  priorities = [...TicketPriority];

  form = { title: '', description: '', category: '', priority: '' };
  fieldErrors: Record<string, string> = {};
  loading = false;
  error = '';

  clearFieldError(key: string) {
    this.fieldErrors = { ...this.fieldErrors, [key]: '' };
  }

  async handleSubmit() {
    const errs: Record<string, string> = {};

    const title = this.form.title.trim();
    if (!title) errs['title'] = 'Title is required';
    else if (title.length < 5) errs['title'] = 'Title must be at least 5 characters';
    else if (title.length > 200) errs['title'] = 'Title must be 200 characters or fewer';

    const description = this.form.description.trim();
    if (!description) errs['description'] = 'Description is required';
    else if (description.length < 10) errs['description'] = 'Description must be at least 10 characters';
    else if (description.length > 2000) errs['description'] = 'Description must be 2000 characters or fewer';

    if (!this.form.category) errs['category'] = 'Please select a category';

    if (Object.keys(errs).length) {
      this.fieldErrors = errs;
      return;
    }

    this.loading = true;
    this.error = '';
    this.fieldErrors = {};

    try {
      await this.ticketApi.create({
        title,
        description,
        category: this.form.category as any,
        priority: (this.form.priority || undefined) as any,
      });
      this.created.emit();
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }
}
