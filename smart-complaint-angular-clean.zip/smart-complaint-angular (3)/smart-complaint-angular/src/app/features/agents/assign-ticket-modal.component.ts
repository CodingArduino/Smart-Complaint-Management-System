import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { AgentApiService } from '../../core/services/agent-api.service';
import { Agent } from '../../core/models/types';

import { ModalComponent } from '../../shared/ui/modal/modal.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';

@Component({
  selector: 'app-assign-ticket-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, ModalComponent, AlertComponent, InputComponent, ButtonComponent],
  templateUrl: './assign-ticket-modal.component.html',
  styleUrls: ['./agent-forms-shared.css'],
})
export class AssignTicketModalComponent {
  private agentApi = inject(AgentApiService);

  @Input() agents: Agent[] = [];
  @Output() closed = new EventEmitter<void>();
  @Output() assigned = new EventEmitter<void>();

  form = { agentId: '', ticketId: '' };
  loading = false;
  error = '';

  get agentOptions() {
    return this.agents.map(a => ({
      value: a.id,
      label: `${a.name} — ${a.specialization} (${a.activeTicketCount} active)`,
    }));
  }

  async handleSubmit() {
    if (!this.form.agentId || !this.form.ticketId) {
      this.error = 'Both agent and ticket ID are required';
      return;
    }

    this.loading = true;
    this.error = '';

    try {
      await this.agentApi.assignTicket({
        agentId: Number(this.form.agentId),
        ticketId: Number(this.form.ticketId),
      });
      this.assigned.emit();
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }
}
