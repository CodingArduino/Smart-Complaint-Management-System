import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, OnInit, Output, inject } from '@angular/core';
import { AgentApiService } from '../../core/services/agent-api.service';
import { AgentSpecialization, User } from '../../core/models/types';

import { ModalComponent } from '../../shared/ui/modal/modal.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';

@Component({
  selector: 'app-register-agent-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, ModalComponent, AlertComponent, InputComponent, ButtonComponent],
  templateUrl: './register-agent-modal.component.html',
  styleUrls: ['./agent-forms-shared.css'],
})
export class RegisterAgentModalComponent implements OnInit {
  private agentApi = inject(AgentApiService);

  @Input() user: User | null = null;
  @Input() isAgent = false;
  @Output() closed = new EventEmitter<void>();
  @Output() registered = new EventEmitter<void>();

  specializations = [...AgentSpecialization];

  form = { name: '', email: '', specialization: '' };
  loading = false;
  error = '';

  ngOnInit() {
    if (this.isAgent) {
      this.form.name = this.user?.name || '';
      this.form.email = this.user?.email || '';
    }
  }

  async handleSubmit() {
    if (!this.form.name || !this.form.email || !this.form.specialization) {
      this.error = 'All fields required';
      return;
    }

    this.loading = true;
    this.error = '';

    try {
      await this.agentApi.register({
        name: this.form.name,
        email: this.form.email,
        specialization: this.form.specialization,
      });
      this.registered.emit();
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }
}
