import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-metric-strip',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="metric-strip">
      <div class="metric-strip-row">
        <span class="metric-strip-label">{{ label }}</span>
        <span class="metric-strip-dot" [style.background]="color" [style.box-shadow]="'0 0 0 6px color-mix(in srgb, ' + color + ' 18%, transparent)'"></span>
      </div>
      <div class="metric-strip-value">{{ value }}</div>
      <div class="metric-strip-hint" *ngIf="hint">{{ hint }}</div>
    </div>
  `,
  styles: [
    `
      .metric-strip {
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding: 14px 16px;
        border-radius: 16px;
        background: rgba(255, 255, 255, 0.025);
        border: 1px solid rgba(255, 255, 255, 0.04);
        min-width: 0;
      }
      .metric-strip-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }
      .metric-strip-label {
        font-size: 0.72rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--text-3);
        font-weight: 700;
      }
      .metric-strip-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        flex-shrink: 0;
      }
      .metric-strip-value {
        font-family: var(--font-display);
        font-size: 1.45rem;
        font-weight: 700;
        line-height: 1;
        color: var(--text);
      }
      .metric-strip-hint {
        font-size: 0.78rem;
        color: var(--text-2);
      }
    `,
  ],
})
export class MetricStripComponent {
  @Input() label = '';
  @Input() value: string | number = '';
  @Input() hint = '';
  @Input() color = 'var(--accent)';
}
