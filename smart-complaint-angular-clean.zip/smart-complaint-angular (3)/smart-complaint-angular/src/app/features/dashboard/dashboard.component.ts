import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { TicketApiService } from '../../core/services/ticket-api.service';
import { AgentApiService } from '../../core/services/agent-api.service';
import { Agent, Ticket } from '../../core/models/types';

import { CardComponent } from '../../shared/ui/card/card.component';
import { StatCardComponent } from '../../shared/ui/stat-card/stat-card.component';
import { PageHeaderComponent } from '../../shared/ui/page-header/page-header.component';
import { SpinnerComponent } from '../../shared/ui/spinner/spinner.component';
import { EmptyComponent } from '../../shared/ui/empty/empty.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';
import { StatusBadgeComponent, PriorityBadgeComponent } from '../../shared/ui/badge/badge.component';
import { MetricStripComponent } from './metric-strip.component';

const CATEGORY_ORDER = ['BILLING', 'TECHNICAL', 'GENERAL', 'COMPLAINT', 'FEEDBACK'];

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    CardComponent,
    StatCardComponent,
    PageHeaderComponent,
    SpinnerComponent,
    EmptyComponent,
    ButtonComponent,
    StatusBadgeComponent,
    PriorityBadgeComponent,
    MetricStripComponent,
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})
export class DashboardComponent implements OnInit {
  private auth = inject(AuthService);
  private ticketApi = inject(TicketApiService);
  private agentApi = inject(AgentApiService);
  private router = inject(Router);

  user = this.auth.user;
  tickets: Ticket[] = [];
  agents: Agent[] = [];
  loading = true;

  categoryOrder = CATEGORY_ORDER;

  async ngOnInit() {
    const isUserRole = this.user()?.role === 'USER';
    const isAdmin = this.user()?.role === 'ADMIN';

    const [tResult, aResult] = await Promise.allSettled([
      isUserRole ? this.ticketApi.getMy() : this.ticketApi.getAll(),
      isAdmin ? this.agentApi.getAll() : Promise.resolve([] as Agent[]),
    ]);

    this.tickets = tResult.status === 'fulfilled' ? tResult.value : [];
    this.agents = aResult.status === 'fulfilled' ? aResult.value : [];
    this.loading = false;
  }

  get counts() {
    return {
      open: this.tickets.filter(t => t.status === 'OPEN').length,
      inProgress: this.tickets.filter(t => t.status === 'IN_PROGRESS').length,
      resolved: this.tickets.filter(t => t.status === 'RESOLVED').length,
      critical: this.tickets.filter(t => t.priority === 'CRITICAL').length,
    };
  }

  get agentCounts() {
    return {
      available: this.agents.filter(a => a.status === 'AVAILABLE').length,
      busy: this.agents.filter(a => a.status === 'BUSY').length,
      offline: this.agents.filter(a => a.status === 'OFFLINE').length,
    };
  }

  get recent(): Ticket[] {
    return [...this.tickets]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 6);
  }

  get greeting(): string {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  get firstName(): string {
    return this.user()?.name?.split(' ')[0] || 'there';
  }

  get totalTickets(): number {
    return this.tickets.length;
  }

  get resolutionRate(): number {
    return this.totalTickets ? Math.round((this.counts.resolved / this.totalTickets) * 100) : 0;
  }

  get todayLabel(): string {
    return new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
  }

  categoryCount(cat: string): number {
    return this.tickets.filter(t => t.category === cat).length;
  }

  categoryPct(cat: string): number {
    return this.tickets.length ? Math.round((this.categoryCount(cat) / this.tickets.length) * 100) : 0;
  }

  goToTickets() {
    this.router.navigateByUrl(this.user()?.role === 'USER' ? '/my-tickets' : '/tickets');
  }

  goToTicket(id: number) {
    this.router.navigateByUrl(`/tickets/${id}`);
  }
}
