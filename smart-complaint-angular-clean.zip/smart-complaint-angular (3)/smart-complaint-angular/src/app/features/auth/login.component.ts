import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { AuthShellComponent } from './auth-shell.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, AuthShellComponent, AlertComponent, InputComponent, ButtonComponent],
  templateUrl: './login.component.html',
  styleUrls: ['./auth-form-shared.css'],
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  form = { email: '', password: '' };
  error = '';
  loading = false;

  async handleSubmit() {
    this.error = '';
    this.loading = true;
    try {
      await this.auth.login(this.form.email, this.form.password);
      this.router.navigateByUrl('/dashboard');
    } catch (err: any) {
      this.error = err.message || 'Login failed';
    } finally {
      this.loading = false;
    }
  }
}
