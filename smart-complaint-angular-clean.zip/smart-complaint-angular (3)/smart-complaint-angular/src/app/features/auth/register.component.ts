import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; 
import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { AuthShellComponent } from './auth-shell.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, AuthShellComponent, AlertComponent, InputComponent, ButtonComponent],
  templateUrl: './register.component.html',
  styleUrls: ['./auth-form-shared.css'],
})
export class RegisterComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  form = { name: '', email: '', password: '', role: 'USER' };
  error = '';
  loading = false;

  roleOptions = [
    { value: 'USER', label: 'User — submit complaints' },
    { value: 'AGENT', label: 'Agent — handle tickets' },
    { value: 'ADMIN', label: 'Admin — full access' },
  ];

  async handleSubmit() {
    this.error = '';

    if (this.form.password.length < 8) {
      this.error = 'Password must be at least 8 characters';
      return;
    }
    if (!/(?=.*[A-Za-z])(?=.*\d)/.test(this.form.password)) {
      this.error = 'Password must contain a letter and a number';
      return;
    }

    this.loading = true;
    try {
      await this.auth.register(this.form.name, this.form.email, this.form.password, this.form.role);
      this.router.navigateByUrl('/dashboard');
    } catch (err: any) {
      this.error = err.message || 'Registration failed';
    } finally {
      this.loading = false;
    }
  }
}
