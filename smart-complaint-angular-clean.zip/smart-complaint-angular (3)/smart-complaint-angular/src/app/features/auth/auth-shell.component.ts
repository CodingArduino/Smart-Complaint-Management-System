import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-auth-shell',
  standalone: true,
  template: `
    <div class="auth-screen">
      <div class="auth-glow auth-glow--top"></div>
      <div class="auth-glow auth-glow--bottom"></div>

      <div class="auth-container">
        <div class="auth-logo-block">
          <div class="auth-logo">
            <span class="auth-logo-glyph">◈</span>
          </div>
          <h1 class="auth-title">{{ title }}</h1>
          <p class="auth-subtitle">{{ subtitle }}</p>
        </div>

        <div class="auth-card">
          <ng-content></ng-content>
        </div>
      </div>
    </div>
  `,
  styleUrl: './auth-shell.component.css',
})
export class AuthShellComponent {
  @Input() title = '';
  @Input() subtitle = '';
}
