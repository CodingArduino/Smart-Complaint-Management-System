import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, inject } from '@angular/core';
import { AuthService } from '../../core/auth/auth.service';
import { NotificationApiService } from '../../core/services/notification-api.service';
import { Notification } from '../../core/models/types';

import { PageHeaderComponent } from '../../shared/ui/page-header/page-header.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { CardComponent } from '../../shared/ui/card/card.component';
import { SpinnerComponent } from '../../shared/ui/spinner/spinner.component';
import { EmptyComponent } from '../../shared/ui/empty/empty.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';
import { BadgeComponent } from '../../shared/ui/badge/badge.component';
import { SendNotificationModalComponent } from './send-notification-modal.component';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    PageHeaderComponent,
    AlertComponent,
    CardComponent,
    SpinnerComponent,
    EmptyComponent,
    ButtonComponent,
    BadgeComponent,
    SendNotificationModalComponent,
  ],
  templateUrl: './notifications.component.html',
  styleUrl: './notifications.component.css',
})
export class NotificationsComponent implements OnInit {
  private auth = inject(AuthService);
  private notificationApi = inject(NotificationApiService);

  user = this.auth.user;

  notifs: Notification[] = [];
  loading = true;
  error = '';
  success = '';
  filter = '';
  showSend = false;

  ngOnInit() {
    this.fetchNotifs();
  }

  async fetchNotifs() {
    this.loading = true;
    try {
      this.notifs =
        this.user()?.role === 'ADMIN'
          ? await this.notificationApi.getAll()
          : await this.notificationApi.getByEmail(this.user()?.email || '');
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }

  get filtered(): Notification[] {
    const f = this.filter.toLowerCase();
    return this.notifs.filter(
      n =>
        !f ||
        n.toEmail?.toLowerCase().includes(f) ||
        n.subject?.toLowerCase().includes(f) ||
        n.eventType?.toLowerCase().includes(f)
    );
  }

  eventColor(type?: string): string {
    if (!type) return 'var(--text-3)';
    if (type.includes('CREATED')) return 'var(--accent)';
    if (type.includes('RESOLVED')) return 'var(--success)';
    if (type.includes('ASSIGNED')) return 'var(--warning)';
    if (type.includes('UPDATE')) return 'var(--info)';
    return 'var(--text-3)';
  }

  get eventStats(): { type: string; count: number }[] {
    const acc: Record<string, number> = {};
    for (const n of this.notifs) {
      const k = n.eventType || 'OTHER';
      acc[k] = (acc[k] || 0) + 1;
    }
    return Object.entries(acc).map(([type, count]) => ({ type, count }));
  }

  onSent() {
    this.fetchNotifs();
    this.showSend = false;
    this.success = 'Notification sent!';
  }
}
