import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, EventEmitter, Output, inject } from '@angular/core';
import { NotificationApiService } from '../../core/services/notification-api.service';

import { ModalComponent } from '../../shared/ui/modal/modal.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';

@Component({
  selector: 'app-send-notification-modal',
  standalone: true,
  imports: [CommonModule, FormsModule, ModalComponent, AlertComponent, InputComponent, ButtonComponent],
  templateUrl: './send-notification-modal.component.html',
  styleUrls: ['./notification-forms-shared.css'],
})
export class SendNotificationModalComponent {
  private notificationApi = inject(NotificationApiService);

  @Output() closed = new EventEmitter<void>();
  @Output() sent = new EventEmitter<void>();

  form = { toEmail: '', subject: '', body: '', ticketId: '', eventType: '' };
  loading = false;
  error = '';

  async handleSubmit() {
    if (!this.form.toEmail || !this.form.subject || !this.form.body) {
      this.error = 'Recipient, subject, and body are required';
      return;
    }

    this.loading = true;
    this.error = '';

    try {
      await this.notificationApi.send({
        toEmail: this.form.toEmail,
        subject: this.form.subject,
        body: this.form.body,
        ticketId: this.form.ticketId || undefined,
        eventType: this.form.eventType || undefined,
      });
      this.sent.emit();
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }
}
