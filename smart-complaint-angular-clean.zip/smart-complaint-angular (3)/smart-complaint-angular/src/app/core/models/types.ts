// ─── Enums matching backend ───────────────────────────────────────────────────

export const TicketStatus = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'] as const;
export type TicketStatusT = (typeof TicketStatus)[number];

export const TicketCategory = ['BILLING', 'TECHNICAL', 'GENERAL', 'COMPLAINT', 'FEEDBACK'] as const;
export type TicketCategoryT = (typeof TicketCategory)[number];

export const TicketPriority = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as const;
export type TicketPriorityT = (typeof TicketPriority)[number];

export const AgentStatus = ['AVAILABLE', 'BUSY', 'OFFLINE'] as const;
export type AgentStatusT = (typeof AgentStatus)[number];

export const AgentSpecialization = ['BILLING', 'TECHNICAL', 'GENERAL', 'COMPLAINT'] as const;
export type AgentSpecializationT = (typeof AgentSpecialization)[number];

export const UserRole = ['USER', 'AGENT', 'ADMIN'] as const;
export type UserRoleT = (typeof UserRole)[number];

// ─── Helper maps ─────────────────────────────────────────────────────────────

export const STATUS_COLOR: Record<string, string> = {
  OPEN: 'var(--status-open)',
  IN_PROGRESS: 'var(--status-inprogress)',
  RESOLVED: 'var(--status-resolved)',
  CLOSED: 'var(--status-closed)',
};

export const PRIORITY_COLOR: Record<string, string> = {
  LOW: 'var(--priority-low)',
  MEDIUM: 'var(--priority-medium)',
  HIGH: 'var(--priority-high)',
  CRITICAL: 'var(--priority-critical)',
};

export const AGENT_STATUS_COLOR: Record<string, string> = {
  AVAILABLE: 'var(--success)',
  BUSY: 'var(--warning)',
  OFFLINE: 'var(--text-3)',
};

export const CATEGORY_ICON: Record<string, string> = {
  BILLING: '💳',
  TECHNICAL: '🔧',
  GENERAL: '📋',
  COMPLAINT: '⚠️',
  FEEDBACK: '💬',
};

// ─── Domain models ────────────────────────────────────────────────────────────

export interface User {
  email: string;
  name: string;
  role: UserRoleT;
}

export interface Ticket {
  id: number;
  title: string;
  description: string;
  category: TicketCategoryT;
  priority: TicketPriorityT;
  status: TicketStatusT;
  submittedByEmail: string;
  assignedAgentEmail?: string | null;
  createdAt: string;
  updatedAt?: string;
  resolvedAt?: string;
}

export interface Agent {
  id: number;
  name: string;
  email: string;
  specialization: AgentSpecializationT;
  status: AgentStatusT;
  statusNote?: string | null;
  activeTicketCount: number;
  createdAt: string;
}

export interface Notification {
  id: number;
  toEmail: string;
  subject: string;
  body: string;
  eventType?: string;
  ticketId?: number;
  createdAt: string;
}
