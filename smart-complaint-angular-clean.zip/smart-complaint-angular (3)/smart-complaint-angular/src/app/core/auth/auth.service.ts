import { Injectable, computed, inject, signal } from '@angular/core';
import { AuthApiService } from '../services/auth-api.service';
import { User } from '../models/types';

const TOKEN_KEY = 'sc_token';
const USER_KEY = 'sc_user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private authApi = inject(AuthApiService);

  // Equivalent to `const [user, setUser] = useState(null)` / `const [loading, setLoading] = useState(true)`
  private userSignal = signal<User | null>(null);
  private loadingSignal = signal<boolean>(true);

  readonly user = computed(() => this.userSignal());
  readonly loading = computed(() => this.loadingSignal());

  constructor() {
    // Equivalent to the useEffect(() => {...}, []) that hydrates from localStorage on mount
    const token = localStorage.getItem(TOKEN_KEY);
    const stored = localStorage.getItem(USER_KEY);
    if (token && stored) {
      try {
        this.userSignal.set(JSON.parse(stored));
      } catch {
        /* ignore corrupt storage */
      }
    }
    this.loadingSignal.set(false);
  }

  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  async login(email: string, password: string): Promise<User> {
    const data = await this.authApi.login({ email, password });
    localStorage.setItem(TOKEN_KEY, data.token);
    const u: User = { email: data.email, name: data.name, role: data.role as User['role'] };
    localStorage.setItem(USER_KEY, JSON.stringify(u));
    this.userSignal.set(u);
    return u;
  }

  async register(name: string, email: string, password: string, role: string): Promise<User> {
    const data = await this.authApi.register({ name, email, password, role });
    localStorage.setItem(TOKEN_KEY, data.token);
    const u: User = { email: data.email, name: data.name, role: data.role as User['role'] };
    localStorage.setItem(USER_KEY, JSON.stringify(u));
    this.userSignal.set(u);
    return u;
  }

  logout(): void {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    this.userSignal.set(null);
  }
}
