import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from './auth.service';

/**
 * Equivalent of the <ProtectedRoute roles={...}> wrapper in App.jsx.
 * Attach required roles via route data, e.g.:
 *   { path: 'agents', canActivate: [authGuard], data: { roles: ['AGENT', 'ADMIN'] } }
 */
export const authGuard: CanActivateFn = (route) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const user = auth.user();
  if (!user) return router.createUrlTree(['/login']);

  const roles = route.data['roles'] as string[] | undefined;
  if (roles && !roles.includes(user.role)) return router.createUrlTree(['/dashboard']);

  return true;
};

/** Equivalent of the <PublicRoute> wrapper in App.jsx (login/register pages). */
export const publicGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.user()) return router.createUrlTree(['/dashboard']);
  return true;
};
