import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, firstValueFrom } from 'rxjs';
import { normalizeHttpError } from './http-error.util';

const BASE = '/api';

export interface LoginResponse {
  token: string;
  email: string;
  name: string;
  role: string;
}

@Injectable({ providedIn: 'root' })
export class AuthApiService {
  private http = inject(HttpClient);

  login(data: { email: string; password: string }) {
    return firstValueFrom(
      this.http
        .post<LoginResponse>(`${BASE}/auth/login`, data)
        .pipe(catchError((e: HttpErrorResponse) => normalizeHttpError(e)))
    );
  }

  register(data: { name: string; email: string; password: string; role: string }) {
    return firstValueFrom(
      this.http
        .post<LoginResponse>(`${BASE}/auth/register`, data)
        .pipe(catchError((e: HttpErrorResponse) => normalizeHttpError(e)))
    );
  }

  health() {
    return firstValueFrom(
      this.http.get(`${BASE}/auth/health`).pipe(catchError((e: HttpErrorResponse) => normalizeHttpError(e)))
    );
  }
}
