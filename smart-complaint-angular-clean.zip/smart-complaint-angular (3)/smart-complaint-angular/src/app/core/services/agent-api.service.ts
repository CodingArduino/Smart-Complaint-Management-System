import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, firstValueFrom } from 'rxjs';
import { normalizeHttpError } from './http-error.util';
import { Agent } from '../models/types';

const BASE = '/api';

@Injectable({ providedIn: 'root' })
export class AgentApiService {
  private http = inject(HttpClient);

  private handle<T>(obs: any) {
    return firstValueFrom(obs.pipe(catchError((e: HttpErrorResponse) => normalizeHttpError(e)))) as Promise<T>;
  }

  register(data: { name: string; email: string; specialization: string }) {
    return this.handle<Agent>(this.http.post<Agent>(`${BASE}/agents`, data));
  }

  getAll() {
    return this.handle<Agent[]>(this.http.get<Agent[]>(`${BASE}/agents`));
  }

  getById(id: number | string) {
    return this.handle<Agent>(this.http.get<Agent>(`${BASE}/agents/${id}`));
  }

  getAvailable() {
    return this.handle<Agent[]>(this.http.get<Agent[]>(`${BASE}/agents/available`));
  }

  assignTicket(data: { agentId: number; ticketId: number }) {
    return this.handle<unknown>(this.http.post(`${BASE}/agents/assign`, data));
  }

  autoAssign(ticketId: number | string, spec: string) {
    return this.handle<unknown>(this.http.post(`${BASE}/agents/auto-assign/${ticketId}/${spec}`, {}));
  }

  updateStatus(id: number | string, status: string, note?: string) {
  return this.handle<Agent>(this.http.patch<Agent>(`${BASE}/agents/${id}/status/${status}`, { note: note || null }));
  }

  health() {
    return this.handle<unknown>(this.http.get(`${BASE}/agents/health`));
  }
}
