import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, firstValueFrom } from 'rxjs';
import { normalizeHttpError } from './http-error.util';
import { Ticket } from '../models/types';

const BASE = '/api';

@Injectable({ providedIn: 'root' })
export class TicketApiService {
  private http = inject(HttpClient);

  private handle<T>(obs: any) {
    return firstValueFrom(obs.pipe(catchError((e: HttpErrorResponse) => normalizeHttpError(e)))) as Promise<T>;
  }

  create(data: Partial<Ticket>) {
    return this.handle<Ticket>(this.http.post<Ticket>(`${BASE}/tickets`, data));
  }

  getAll() {
    return this.handle<Ticket[]>(this.http.get<Ticket[]>(`${BASE}/tickets`));
  }

  getById(id: number | string) {
    return this.handle<Ticket>(this.http.get<Ticket>(`${BASE}/tickets/${id}`));
  }

  getMy() {
    return this.handle<Ticket[]>(this.http.get<Ticket[]>(`${BASE}/tickets/my`));
  }

  getByEmail(email: string) {
    return this.handle<Ticket[]>(this.http.get<Ticket[]>(`${BASE}/tickets/user/${email}`));
  }

  getByStatus(status: string) {
    return this.handle<Ticket[]>(this.http.get<Ticket[]>(`${BASE}/tickets/status/${status}`));
  }

  getUnassigned() {
    return this.handle<Ticket[]>(this.http.get<Ticket[]>(`${BASE}/tickets/unassigned`));
  }

  updateStatus(id: number | string, data: { status: string; agentEmail?: string }) {
    return this.handle<Ticket>(this.http.patch<Ticket>(`${BASE}/tickets/${id}/status`, data));
  }

  assign(id: number | string, email: string) {
    return this.handle<Ticket>(this.http.patch<Ticket>(`${BASE}/tickets/${id}/assign/${email}`, {}));
  }

  health() {
    return this.handle<unknown>(this.http.get(`${BASE}/tickets/health`));
  }
}
