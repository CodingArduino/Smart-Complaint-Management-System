import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, firstValueFrom } from 'rxjs';
import { normalizeHttpError } from './http-error.util';
import { Notification } from '../models/types';

const BASE = '/api';

@Injectable({ providedIn: 'root' })
export class NotificationApiService {
  private http = inject(HttpClient);

  private handle<T>(obs: any) {
    return firstValueFrom(obs.pipe(catchError((e: HttpErrorResponse) => normalizeHttpError(e)))) as Promise<T>;
  }

  send(data: { toEmail: string; subject: string; body: string; ticketId?: string; eventType?: string }) {
    return this.handle<Notification>(this.http.post<Notification>(`${BASE}/notifications/send`, data));
  }

  getAll() {
    return this.handle<Notification[]>(this.http.get<Notification[]>(`${BASE}/notifications`));
  }

  getByEmail(email: string) {
    return this.handle<Notification[]>(this.http.get<Notification[]>(`${BASE}/notifications/user/${email}`));
  }

  getByTicket(ticketId: number | string) {
    return this.handle<Notification[]>(this.http.get<Notification[]>(`${BASE}/notifications/ticket/${ticketId}`));
  }

  health() {
    return this.handle<unknown>(this.http.get(`${BASE}/notifications/health`));
  }
}
