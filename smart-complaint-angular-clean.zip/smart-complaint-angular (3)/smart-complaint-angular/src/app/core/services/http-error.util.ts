import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

/**
 * Mirrors the error-message extraction logic from the original api.js `request()`
 * helper, so components can keep doing `catch (e) { setError(e.message) }`-style
 * handling unchanged.
 */
export function normalizeHttpError(err: HttpErrorResponse) {
  let msg = `HTTP ${err.status}`;
  const data = err.error;

  if (data && typeof data === 'object') {
    if (data.fieldErrors && typeof data.fieldErrors === 'object') {
      // Spring @Valid: { error: "Validation failed", fieldErrors: { field: "message" } }
      msg = Object.entries(data.fieldErrors)
        .map(([field, message]) => `${field}: ${message}`)
        .join(' · ');
    } else if (Array.isArray(data)) {
      msg = data.map((e: any) => e.message || e.defaultMessage || JSON.stringify(e)).join(' · ');
    } else {
      msg = data.message || data.error || data.detail || JSON.stringify(data);
    }
  } else if (typeof data === 'string' && data) {
    msg = data;
  }

  return throwError(() => new Error(msg));
}
