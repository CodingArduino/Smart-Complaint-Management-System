import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { CardComponent } from '../card/card.component';

@Component({
  selector: 'app-stat-card',
  standalone: true,
  imports: [CommonModule, CardComponent],
  template: `
    <app-card class="stat-card">
      <div class="stat-card-stripe" [style.background]="color"></div>
      <div class="stat-card-row">
        <div>
          <div class="stat-card-label">{{ label }}</div>
          <div class="stat-card-value">{{ value }}</div>
          <div class="stat-card-sub" *ngIf="sub">{{ sub }}</div>
        </div>
        <div class="stat-card-icon" *ngIf="icon" [style.background]="tone(color)" [style.color]="color" [style.border-color]="tone(color, '40')">
          {{ icon }}
        </div>
      </div>
    </app-card>
  `,
  styles: [
    `
      .stat-card {
        position: relative;
        display: block;
        overflow: hidden;
        padding: 18px 18px 16px;
      }
      .stat-card-stripe {
        position: absolute;
        inset: 0 auto 0 0;
        width: 4px;
        opacity: 0.9;
      }
      .stat-card-row {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 12px;
      }
      .stat-card-label {
        font-size: 0.72rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--text-3);
        font-weight: 700;
      }
      .stat-card-value {
        font-size: 2rem;
        font-weight: 700;
        font-family: var(--font-display);
        color: var(--text);
        margin-top: 10px;
        line-height: 1;
      }
      .stat-card-sub {
        font-size: 0.78rem;
        color: var(--text-2);
        margin-top: 7px;
      }
      .stat-card-icon {
        min-width: 40px;
        height: 40px;
        border-radius: 14px;
        display: grid;
        place-items: center;
        font-size: 1rem;
        border: 1px solid;
      }
    `,
  ],
})
export class StatCardComponent {
  @Input() label = '';
  @Input() value: string | number = '';
  @Input() color = 'var(--accent)';
  @Input() icon = '';
  @Input() sub = '';

  tone(color: string, alpha = '22'): string {
    if (!color || color.startsWith('var(')) return `color-mix(in srgb, ${color} 16%, transparent)`;
    return `${color}${alpha}`;
  }
}
