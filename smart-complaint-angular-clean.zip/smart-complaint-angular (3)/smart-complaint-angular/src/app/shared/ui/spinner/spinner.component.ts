import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-spinner',
  standalone: true,
  template: `
    <div
      class="spinner"
      [style.width.px]="size"
      [style.height.px]="size"
      [style.border]="'2px solid color-mix(in srgb, ' + color + ' 24%, transparent)'"
      [style.border-top]="'2px solid ' + color"
    ></div>
  `,
  styles: [
    `
      .spinner {
        border-radius: 50%;
        animation: app-spin 0.7s linear infinite;
        flex-shrink: 0;
      }
      @keyframes app-spin {
        to { transform: rotate(360deg); }
      }
    `,
  ],
})
export class SpinnerComponent {
  @Input() size = 22;
  @Input() color = 'var(--accent)';
}
