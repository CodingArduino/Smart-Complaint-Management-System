import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

export type AlertType = 'error' | 'success' | 'warning' | 'info';

interface AlertCfg {
  bg: string;
  border: string;
  color: string;
  icon: string;
}

const CONFIG: Record<AlertType, AlertCfg> = {
  error: { bg: 'rgba(239,68,68,0.10)', border: 'rgba(239,68,68,0.24)', color: '#ffb4b4', icon: '✕' },
  success: { bg: 'rgba(34,197,94,0.10)', border: 'rgba(34,197,94,0.24)', color: '#9ae6b4', icon: '✓' },
  warning: { bg: 'rgba(245,158,11,0.10)', border: 'rgba(245,158,11,0.24)', color: '#f6d27a', icon: '!' },
  info: { bg: 'rgba(6,182,212,0.10)', border: 'rgba(6,182,212,0.24)', color: '#8ee7f4', icon: 'i' },
};

@Component({
  selector: 'app-alert',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div
      class="alert"
      [style.background]="cfg.bg"
      [style.border-color]="cfg.border"
      [style.color]="cfg.color"
    >
      <span class="alert-icon">{{ cfg.icon }}</span>
      <span class="alert-message">{{ message }}</span>
      <button *ngIf="closable" class="alert-close" (click)="closed.emit()" [style.color]="cfg.color">×</button>
    </div>
  `,
  styles: [
    `
      .alert {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        border: 1px solid;
        border-radius: var(--radius);
        padding: 12px 14px;
        font-size: 0.88rem;
        animation: alertFadeUp 0.2s ease;
      }
      .alert-icon { font-weight: 700; flex-shrink: 0; }
      .alert-message { flex: 1; line-height: 1.5; }
      .alert-close {
        background: none;
        border: none;
        opacity: 0.7;
        cursor: pointer;
        font-size: 1rem;
        line-height: 1;
      }
      @keyframes alertFadeUp {
        from { opacity: 0; transform: translateY(14px); }
        to { opacity: 1; transform: translateY(0); }
      }
    `,
  ],
})
export class AlertComponent {
  @Input() type: AlertType = 'error';
  @Input() message = '';
  /** Whether a close (×) button is shown — pass `closed` handler to enable, same as `onClose` in React. */
  @Input() closable = true;
  @Output() closed = new EventEmitter<void>();

  get cfg(): AlertCfg {
    return CONFIG[this.type];
  }
}
