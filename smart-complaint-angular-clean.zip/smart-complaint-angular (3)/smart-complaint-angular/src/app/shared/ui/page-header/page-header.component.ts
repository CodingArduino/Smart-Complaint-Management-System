import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-page-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-header">
      <div>
        <h1 class="page-header-title">{{ title }}</h1>
        <p class="page-header-subtitle" *ngIf="subtitle">{{ subtitle }}</p>
      </div>
      <div class="page-header-action" *ngIf="hasAction">
        <ng-content></ng-content>
      </div>
    </div>
  `,
  styles: [
    `
      .page-header {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        margin-bottom: 28px;
        gap: 16px;
        flex-wrap: wrap;
      }
      .page-header-title {
        font-family: var(--font-display);
        font-weight: 700;
        font-size: 1.65rem;
        color: var(--text);
        letter-spacing: -0.03em;
        line-height: 1.1;
      }
      .page-header-subtitle {
        color: var(--text-2);
        margin-top: 7px;
        font-size: 0.92rem;
        line-height: 1.5;
      }
      .page-header-action {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
      }
    `,
  ],
})
export class PageHeaderComponent {
  @Input() title = '';
  @Input() subtitle = '';
  /** Set true when projecting action buttons (mirrors the `action` prop being truthy). */
  @Input() hasAction = false;
}
