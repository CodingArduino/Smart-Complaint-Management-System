import { Component, EventEmitter, HostBinding, HostListener, Input, Output } from '@angular/core';

@Component({
  selector: 'app-card',
  standalone: true,
  template: `<ng-content></ng-content>`,
  styleUrl: './card.component.css',
})
export class CardComponent {
  /** Enables the hover lift effect even without a click handler (mirrors `hover` prop). */
  @Input() hover = false;
  @Output() cardClick = new EventEmitter<Event>();

  @HostBinding('class.app-card') cardClass = true;
  @HostBinding('class.app-card--interactive')
  get interactive() {
    return this.hover || this.cardClick.observed;
  }

  @HostListener('click', ['$event'])
  onClick(e: Event) {
    if (this.cardClick.observed) this.cardClick.emit(e);
  }
}
