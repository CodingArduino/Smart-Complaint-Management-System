import { Component, Input } from '@angular/core';
import { AGENT_STATUS_COLOR, CATEGORY_ICON, PRIORITY_COLOR, STATUS_COLOR } from '../../../core/models/types';

@Component({
  selector: 'app-badge',
  standalone: true,
  template: `
    <span
      class="badge"
      [style.background]="tone(color)"
      [style.color]="color"
      [style.border-color]="tone(color, '44')"
    >
      <span class="badge-dot" [style.background]="color" [style.box-shadow]="'0 0 0 4px ' + tone(color, '18')"></span>
      {{ label }}
    </span>
  `,
  styles: [
    `
      .badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 0.68rem;
        font-weight: 700;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        border: 1px solid;
        line-height: 1.2;
      }
      .badge-dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
      }
    `,
  ],
})
export class BadgeComponent {
  @Input() label = '';
  @Input() color = 'var(--text-3)';

  tone(color: string, alpha = '22'): string {
    if (!color || color.startsWith('var(')) return `color-mix(in srgb, ${color} 16%, transparent)`;
    return `${color}${alpha}`;
  }
}

@Component({
  selector: 'app-status-badge',
  standalone: true,
  imports: [BadgeComponent],
  template: `<app-badge [label]="(status || '').replace('_', ' ')" [color]="STATUS_COLOR[status] || 'var(--text-3)'" />`,
})
export class StatusBadgeComponent {
  @Input() status = '';
  STATUS_COLOR = STATUS_COLOR;
}

@Component({
  selector: 'app-priority-badge',
  standalone: true,
  imports: [BadgeComponent],
  template: `<app-badge [label]="priority" [color]="PRIORITY_COLOR[priority] || 'var(--text-3)'" />`,
})
export class PriorityBadgeComponent {
  @Input() priority = '';
  PRIORITY_COLOR = PRIORITY_COLOR;
}

@Component({
  selector: 'app-agent-status-badge',
  standalone: true,
  imports: [BadgeComponent],
  template: `<app-badge [label]="status" [color]="AGENT_STATUS_COLOR[status] || 'var(--text-3)'" />`,
})
export class AgentStatusBadgeComponent {
  @Input() status = '';
  AGENT_STATUS_COLOR = AGENT_STATUS_COLOR;
}

@Component({
  selector: 'app-category-badge',
  standalone: true,
  template: `
    <span class="category-badge">
      <span>{{ CATEGORY_ICON[category] }}</span>
      <span>{{ category }}</span>
    </span>
  `,
  styles: [
    `
      .category-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 10px;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.035);
        border: 1px solid var(--border);
        color: var(--text-2);
        font-size: 0.76rem;
        font-weight: 600;
      }
    `,
  ],
})
export class CategoryBadgeComponent {
  @Input() category = '';
  CATEGORY_ICON = CATEGORY_ICON;
}
