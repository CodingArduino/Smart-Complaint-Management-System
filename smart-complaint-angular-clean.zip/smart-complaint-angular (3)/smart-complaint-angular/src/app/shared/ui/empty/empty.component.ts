import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-empty',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="empty">
      <div class="empty-icon">{{ icon }}</div>
      <div class="empty-title">{{ title }}</div>
      <div class="empty-subtitle" *ngIf="subtitle">{{ subtitle }}</div>
      <div class="empty-action" *ngIf="hasAction"><ng-content></ng-content></div>
    </div>
  `,
  styles: [
    `
      .empty {
        text-align: center;
        padding: 64px 20px;
        color: var(--text-3);
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      .empty-icon {
        width: 64px;
        height: 64px;
        border-radius: 20px;
        display: grid;
        place-items: center;
        background: linear-gradient(180deg, var(--surface), var(--surface-2));
        border: 1px solid var(--border);
        margin-bottom: 14px;
        font-size: 1.8rem;
        box-shadow: var(--shadow);
      }
      .empty-title {
        font-size: 1rem;
        font-weight: 700;
        color: var(--text);
        margin-bottom: 6px;
      }
      .empty-subtitle {
        font-size: 0.86rem;
        color: var(--text-2);
        max-width: 420px;
      }
      .empty-action {
        margin-top: 18px;
      }
    `,
  ],
})
export class EmptyComponent {
  @Input() icon = '📭';
  @Input() title = '';
  @Input() subtitle = '';
  /** Set true when projecting action content into the empty state (mirrors the `action` prop). */
  @Input() hasAction = false;
}
