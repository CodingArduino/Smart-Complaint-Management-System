import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, booleanAttribute } from '@angular/core';

export interface SelectOption {
  value: string | number;
  label: string;
}

@Component({
  selector: 'app-input',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="field-wrap">
      <label class="field-label" *ngIf="label">
        {{ label }}
        <span *ngIf="required" class="required-mark"> *</span>
      </label>

      <textarea
        *ngIf="controlType == 'textarea'"
        class="field"
        [class.field--error]="!!error"
        [rows]="rows || 3"
        [style.min-height.px]="(rows || 3) * 28"
        [placeholder]="placeholder"
        [name]="name"
        [disabled]="disabled"
        [value]="value"
        (input)="onInput($event)"
      ></textarea>

      <select
        *ngIf="controlType == 'select'"
        class="field"
        [class.field--error]="!!error"
        [name]="name"
        [disabled]="disabled"
        [value]="value"
        (change)="onInput($event)"
      >
        <option value="">{{ placeholder || 'Select ' + label }}</option>
        <option *ngFor="let o of normalizedOptions" [value]="o.value">{{ o.label }}</option>
      </select>

      <input
        *ngIf="controlType != 'textarea' && controlType != 'select'"
        class="field"
        [class.field--error]="!!error"
        [type]="type"
        [placeholder]="placeholder"
        [required]="required"
        [name]="name"
        [disabled]="disabled"
        [value]="value"
        (input)="onInput($event)"
      />

      <span class="field-error" *ngIf="error">{{ error }}</span>
    </div>
  `,
  styleUrl: './input.component.css',
})
export class InputComponent {
  @Input() label = '';
  @Input() error = '';
  @Input() type: string = 'text';
  @Input() value: string | number = '';
  @Input() placeholder = '';
  @Input({ transform: booleanAttribute }) required = false;
  @Input() controlType: 'input' | 'textarea' | 'select' = 'input';
  @Input() rows?: number;
  /** Accepts either raw string[]/number[] or {value,label}[] — mirrors the React Input's `options` prop. */
  @Input() options: (SelectOption | string | number)[] = [];
  @Input() name = '';
  @Input({ transform: booleanAttribute }) disabled = false;

  @Output() valueChange = new EventEmitter<string>();

  get normalizedOptions(): SelectOption[] {
    return this.options.map(o =>
      typeof o === 'object' ? o : { value: o, label: String(o) }
    );
  }

  onInput(e: Event) {
    const target = e.target as HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement;
    this.valueChange.emit(target.value);
  }
}
