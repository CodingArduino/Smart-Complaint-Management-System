# SmartComplaint — Frontend (Angular)

This is a full Angular 18 (standalone components, signals) port of the original
React + Vite frontend. Same pages, same routes, same role-based access, same
visual design (dark theme, CSS custom properties) — rebuilt with Angular idioms.

## Tech Stack

- **Angular 18** (standalone components, no NgModules) — routing & SPA
- **Angular Router** — replaces react-router-dom, same route table
- **Signals** — replaces React `useState`/context for the auth store
- **HttpClient + a functional interceptor** — replaces the hand-rolled `fetch` wrapper in api.js
- **Plain CSS** (the same design tokens from `global.css`, copied verbatim into `src/styles.css`)

## Project Structure

```
src/
├── main.ts                      # Entry point (bootstrapApplication)
├── styles.css                   # Design tokens, reset, animations (unchanged from global.css)
├── index.html
│
└── app/
    ├── app.component.ts          # Root shell — just a <router-outlet>
    ├── app.routes.ts             # Route table + guards (replaces App.jsx's <Routes>)
    ├── app.config.ts             # Providers: router, HttpClient + interceptor
    │
    ├── core/
    │   ├── models/types.ts       # Enums + color maps (from shared/types/index.js)
    │   ├── services/             # ticket-api / agent-api / notification-api / auth-api
    │   │                         #   (split out of the single api.js file, one service per domain)
    │   └── auth/
    │       ├── auth.service.ts   # Signal-based store (replaces useAuth.jsx's context)
    │       ├── auth.guards.ts    # authGuard / publicGuard (replaces ProtectedRoute/PublicRoute)
    │       └── auth.interceptor.ts  # Attaches Bearer token (replaces authHeaders())
    │
    ├── shared/
    │   ├── ui/                   # Button, Input, Badge (+ variants), Card, Modal,
    │   │                         #   Alert, Empty, PageHeader, StatCard, Spinner
    │   │                         #   (one component per file, converted from ui.jsx)
    │   └── layout/                # Sidebar + shell (from Layout.jsx)
    │
    └── features/
        ├── auth/                  # LoginComponent, RegisterComponent, AuthShell
        ├── dashboard/              # DashboardComponent + MetricStrip
        ├── tickets/                # TicketsComponent, MyTicketsComponent,
        │                           #   TicketDetailComponent, CreateTicketModal, TicketCard
        ├── agents/                 # AgentsComponent, RegisterAgentModal, AssignTicketModal
        └── notifications/          # NotificationsComponent, SendNotificationModal
```

## Notable conversion decisions

- **The generic `<Table columns={...} render={...}>` component from `ui.jsx` was not ported 1:1.**
  React's "columns array with render-prop cells" pattern doesn't map cleanly onto Angular
  templates. Instead, each page (Tickets, Agents, Notifications) renders its own native
  `<table>` with `*ngFor`, which is the idiomatic Angular way to do the same job and keeps
  the exact same visual output.
- **Inline style objects + `onMouseEnter`/`onMouseLeave` JS hover handlers were converted to
  plain CSS with `:hover` rules** in each component's `.css` file, instead of replicating
  imperative DOM style mutation in TypeScript.
- **The React Context (`AuthProvider`/`useAuth`) became a root-provided `AuthService`**
  using Angular signals (`user`, `loading`) — no provider wrapper needed, since Angular
  services are already app-wide singletons via `providedIn: 'root'`.
- **Route guards** (`ProtectedRoute`/`PublicRoute` wrapper components) became Angular
  `CanActivate`/`CanActivateChild` functional guards, with required roles passed through
  route `data`, exactly mirroring the `roles={[...]}` prop from the original routes.
- **Layout** is now a parent route (`LayoutComponent` with a nested `<router-outlet>`),
  which is the standard Angular way to express "wrap these routes in a shell" instead of
  wrapping `<Layout>{children}</Layout>` per-route like the JSX did.

## Prerequisites

Same as the original — all backend microservices running:
- Eureka Server: `http://localhost:8761`
- API Gateway: `http://localhost:8080`

## Install & Run

```bash
npm install
npm start
# Open http://localhost:3000
```

`proxy.conf.json` proxies `/api` to `http://localhost:8080`, same as the original
`vite.config.js` dev-server proxy.

### Build

```bash
npm run build
```

## Role-Based Access

Unchanged from the original:

| Route            | USER | AGENT | ADMIN |
|-------------------|------|-------|-------|
| /dashboard        | ✅   | ✅    | ✅    |
| /my-tickets       | ✅   | ✗     | ✗     |
| /tickets          | ✗    | ✅    | ✅    |
| /tickets/:id      | ✅   | ✅    | ✅    |
| /agents           | ✗    | ✅    | ✅    |
| /notifications    | ✗    | ✗     | ✅    |
