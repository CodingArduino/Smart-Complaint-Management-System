import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';

interface NavItem {
  to: string;
  icon: string;
  label: string;
  roles?: string[];
}

const NAV: NavItem[] = [
  { to: '/dashboard', icon: '◫', label: 'Dashboard' },
  { to: '/tickets', icon: '⌘', label: 'Tickets', roles: ['USER', 'AGENT', 'ADMIN'] },
  { to: '/my-tickets', icon: '•', label: 'My Tickets', roles: ['USER'] },
  { to: '/agents', icon: '◌', label: 'Agents', roles: ['AGENT', 'ADMIN'] },
  { to: '/notifications', icon: '✦', label: 'Notifications', roles: ['ADMIN'] },
];

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './layout.component.html',
  styleUrl: './layout.component.css',
})
export class LayoutComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  nav = NAV;
  user = this.auth.user;

  get visibleNav(): NavItem[] {
    const role = this.user()?.role;
    return NAV.filter(n => !n.roles || (role && n.roles.includes(role)));
  }

  get initials(): string {
    return this.user()?.name?.slice(0, 2)?.toUpperCase() || 'SC';
  }

  logout() {
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }
}
