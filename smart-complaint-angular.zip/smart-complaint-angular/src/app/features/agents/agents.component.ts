import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Component, OnInit, inject } from '@angular/core';
import { AuthService } from '../../core/auth/auth.service';
import { AgentApiService } from '../../core/services/agent-api.service';
import { Agent, AgentStatus } from '../../core/models/types';

import { PageHeaderComponent } from '../../shared/ui/page-header/page-header.component';
import { AlertComponent } from '../../shared/ui/alert/alert.component';
import { CardComponent } from '../../shared/ui/card/card.component';
import { EmptyComponent } from '../../shared/ui/empty/empty.component';
import { ButtonComponent } from '../../shared/ui/button/button.component';
import { InputComponent } from '../../shared/ui/input/input.component';
import { AgentStatusBadgeComponent, BadgeComponent } from '../../shared/ui/badge/badge.component';
import { RegisterAgentModalComponent } from './register-agent-modal.component';
import { AssignTicketModalComponent } from './assign-ticket-modal.component';

@Component({
  selector: 'app-agents',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    PageHeaderComponent,
    AlertComponent,
    CardComponent,
    EmptyComponent,
    ButtonComponent,
    InputComponent,
    AgentStatusBadgeComponent,
    BadgeComponent,
    RegisterAgentModalComponent,
    AssignTicketModalComponent,
  ],
  templateUrl: './agents.component.html',
  styleUrl: './agents.component.css',
})
export class AgentsComponent implements OnInit {
  private auth = inject(AuthService);
  private agentApi = inject(AgentApiService);

  user = this.auth.user;

  agents: Agent[] = [];
  loading = true;
  error = '';
  success = '';
  showRegister = false;
  showAssign = false;
  filterStatus = '';

  statuses = ['', ...AgentStatus];
  statusOptions = [...AgentStatus].map(s => ({ value: s, label: s.charAt(0) + s.slice(1).toLowerCase() }));

  // ── Self-service "set my status" state ──
  myStatusForm = { status: '', note: '' };
  updatingMyStatus = false;

  get isAdmin(): boolean {
    return this.user()?.role === 'ADMIN';
  }

  get isAgentRole(): boolean {
    return this.user()?.role === 'AGENT';
  }

  get myAgent(): Agent | undefined {
    return this.agents.find(a => a.email === this.user()?.email);
  }

  ngOnInit() {
    this.fetchAgents();
  }

  async fetchAgents() {
    this.loading = true;
    try {
      this.agents = await this.agentApi.getAll();

      const mine = this.myAgent;
      if (mine) {
        this.myStatusForm = { status: mine.status, note: mine.statusNote || '' };
      }
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.loading = false;
    }
  }

  async handleStatusChange(agent: Agent, status: string) {
    try {
      await this.agentApi.updateStatus(agent.id, status);
      this.success = `${agent.name} is now ${status}`;
      this.fetchAgents();
    } catch (e: any) {
      this.error = e.message;
    }
  }

  async updateMyStatus() {
    const mine = this.myAgent;
    if (!mine || !this.myStatusForm.status) return;

    this.updatingMyStatus = true;
    this.error = '';
    this.success = '';

    try {
      await this.agentApi.updateStatus(mine.id, this.myStatusForm.status, this.myStatusForm.note.trim());
      this.success = 'Your status has been updated';
      await this.fetchAgents();
    } catch (e: any) {
      this.error = e.message;
    } finally {
      this.updatingMyStatus = false;
    }
  }

  get filtered(): Agent[] {
    return this.agents.filter(a => !this.filterStatus || a.status === this.filterStatus);
  }

  countByStatus(status: string): number {
    return this.agents.filter(a => a.status === status).length;
  }

  otherStatuses(status: string): string[] {
    return AgentStatus.filter(s => s !== status);
  }

  onRegistered() {
    this.fetchAgents();
    this.showRegister = false;
    this.success = 'Agent registered successfully!';
  }

  get availableAgents(): Agent[] {
    return this.agents.filter(a => a.status === 'AVAILABLE');
  }

  onAssigned() {
    this.fetchAgents();
    this.showAssign = false;
    this.success = 'Ticket assigned successfully!';
  }
}
